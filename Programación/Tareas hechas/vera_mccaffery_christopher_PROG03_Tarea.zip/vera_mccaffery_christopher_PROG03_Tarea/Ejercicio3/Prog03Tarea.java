/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author gogloglo
 */
public class Prog03Tarea {
    public static void main (String args[]){
        //Creamos un objeto "Trabajador" sin pasarle parámetros para que utilice los que tiene por defecto.
        Trabajador trabajador = new Trabajador();
        //Mostramos los atributos del objeto Trabajador.
        System.out.println("Nombre: "+trabajador.consulta_Nombre()+"\nAltura: "+trabajador.consulta_Altura()+"\nEdad: "+trabajador.consulta_Edad());
    }
}
