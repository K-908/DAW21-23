//Importamos la utilidad Scanner para poder introducir texto por el teclado.
import java.util.Scanner;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author gogloglo
 */
public class Prog03Tarea {
    //Clase main
    public static void main (String args[]){
        //Creamos un objeto Scanner
        Scanner reader = new Scanner(System.in);
        System.out.println("Introduce el nombre del trabajador: ");
        //Creamos una variable "nombre" para guardar el nombre que asignar al objeto Trabajador
        String nombre = reader.nextLine();
        //Creamos un objeto Trabajador con la variable nombre como parámetro
        Trabajador trabajador = new Trabajador(nombre);
        //Devolvemos el nombre del trabajador con el método consulta_Nombre()
        System.out.println("El nombre del trabajador es "+trabajador.consulta_Nombre());
        //Cambiamos el atributo "altura" con el método cambiaAltura()
        trabajador.cambiaAltura(2.15f);
        //Cambiamos el atributo "edad" con el método cambiaEdad;
        trabajador.cambiaEdad(85);
        //Cambiamos el atributo "nombre" con el método cambia_Nombre();
        trabajador.cambia_Nombre("Pepito");
        //Mostramos por pantalla todos los atributos modificados del objeto trabajador
        System.out.println("Nombre: "+trabajador.consulta_Nombre()+"\nEdad: "+trabajador.consulta_Edad()+"\nAltura: "+trabajador.consulta_Altura());
    }
}
