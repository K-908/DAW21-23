/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author gogloglo
 */
public class Trabajador {
    String nombre;
    int edad;
    float altura;
    
    //Constructor que toma una variable de tipo String como parámetro y la asigna a la variable "nombre" del objeto
    public Trabajador(String nombre){
        this.nombre = nombre;
    }
    //Método que devuelve un String con el nombre del objeto Trabajador
    String consulta_Nombre(){
        return nombre;
 }
    //Método que devuelve un int con el valor de la variable "edad" del objeto
    int consulta_Edad(){
        return edad;
    }
    //Método que devuelve un float con el valor de la variable "altura" del objeto
    float consulta_Altura(){
        return altura;
    }
    //Método que recibe un String como parámetro y cambia la variable "nombre" del objeto
    void cambia_Nombre(String nom){
        nombre=nom;
 }
    //Método que recibe un int como parámetro y cambia la variable "edad" del objeto
    void cambiaEdad(int ed){
        edad = ed;
    }
    //Método que recibe un float como parámetro y cambia la variable "altura" del objeto
    void cambiaAltura(float alt){
        altura = alt;
    }
}
