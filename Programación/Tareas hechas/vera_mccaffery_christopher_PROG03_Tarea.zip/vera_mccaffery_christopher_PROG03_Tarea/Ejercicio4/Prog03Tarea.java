/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author gogloglo
 */
public class Prog03Tarea {
    public static void main (String args[]){
        //Creamos un objeto de clase Trabajador y le pasamos como parámetros los valores de todas las variables
        Trabajador trabajador = new Trabajador("Pepe", 29, 1.74f);
        //Mostramos por pantalla los valores de las variables del objet Trabajador
        System.out.println("Nombre: "+trabajador.consulta_Nombre()+"\nAltura: "+trabajador.consulta_Altura()+"\nEdad: "+trabajador.consulta_Edad());
    }
}
