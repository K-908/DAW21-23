
import numeros.Complejo;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author gogloglo
 */
public class Prog03Tarea {
    public static void main (String args[]){
        //Creamos un objeto de tipo Complejo y le pasamos los valores de las variables como parámetros
        Complejo c1 = new Complejo(2.0, 0.1);
        //Mostramos por pantalla los valores de las variables llamando a los métodos consulta_Real() y consulta_Imag()
        System.out.println("Real: "+c1.consulta_Real()+"\nImaginario: "+c1.consulta_Imag());
        //Mostramos por pantalla el resultado del método toString()
        System.out.println(c1.toString());
        //Cambiamos el valor de la variable "real"
        c1.cambia_Real(3.0);
        //Cambiamos el valor de la variable "imaginario"
        c1.cambia_Imag(0.4);
        //Volvemos a mostrar por pantalla el resultado del método toString() para comprobar que se ha hecho el cambio
        System.out.println(c1.toString());
        //Creamos un nuevo objeto Complejo
        Complejo c2 = new Complejo(6.0, 0.5);
        //Sumamos los valores de las variable del objeto c2 a las del objeto c1
        c1.sumar(c2);
        //Volvemos a mostrar por pantalla el resultado del método toString() para comprobar que se ha hecho el cambio
        System.out.println(c1.toString());
    }
}
