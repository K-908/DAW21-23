//Esta clase está en el paquete números en vez de en el paquete por defecto
package numeros;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author gogloglo
 */
public class Complejo {
    double real;
    double imaginario;
    
    //Constructor sin parámetros que asigna el valor 0 a ambas variables
    public Complejo(){
        this.real = 0;
        this.imaginario = 0;
    }
    //Constructor con dos parámetros de tipo double para asignar a las variables del objeto
    public Complejo(double real, double imag){
        this.real = real;
        this.imaginario = imag;
    }
    
    //Método que devuelve una variable double con el valor de la variable "real" del objeto
    public double consulta_Real(){
        return this.real;
    }
    //Método que devuelve una variable double con el valor de la variable "imaginario" del objeto
    public double consulta_Imag(){
        return this.imaginario;
    }
    //Método que recibe como parámetro una variable de tipo double y asigna ese valor a la variable "real" del objeto
    public void cambia_Real(double real){
        this.real = real;
    }
    //Método que recibe como parámetro una variable de tipo double y asigna ese valor a la variable "imaginario" del objeto
    public void cambia_Imag(double imag){
        this.imaginario = imag;
    }
    //Método que devuelve un String con los valores de las variables del objeto
    @Override
    public String toString(){
        return this.real+" + "+this.imaginario+"i";
    }
    //Método que recibe un objeto de la clase Complejo como parámetro y suma el valor de su variable "real" al de la variable "real" del objeto que lo llama, y lo mismo con la variable "imaginario"
    public void sumar(Complejo b){
        this.real+=b.real;
        this.imaginario+=b.imaginario;
    }
}
