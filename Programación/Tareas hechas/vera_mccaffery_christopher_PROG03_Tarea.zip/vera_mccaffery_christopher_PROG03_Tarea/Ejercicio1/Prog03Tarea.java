//Importamos la utilidad Scanner para poder introducir texto por el teclado.
import java.util.Scanner;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author gogloglo
 */

public class Prog03Tarea {
//Clase main
    public static void main (String args[]){
        //Creamos un objeto Scanner
        Scanner reader = new Scanner(System.in);
        System.out.println("Introduce el nombre del trabajador: ");
        //Creamos una variable "nombre" para guardar el nombre que asignar al objeto Trabajador
        String nombre = reader.nextLine();
        //Creamos un objeto Trabajador con la variable nombre como parámetro
        Trabajador trabajador = new Trabajador(nombre);
        //Devolvemos el nombre del trabajador con el método consulta_Nombre()
        System.out.println("El nombre del trabajador es "+trabajador.consulta_Nombre());
    }
}
