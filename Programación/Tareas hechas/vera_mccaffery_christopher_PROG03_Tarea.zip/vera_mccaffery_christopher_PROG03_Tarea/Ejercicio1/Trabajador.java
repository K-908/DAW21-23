/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author gogloglo
 */
public class Trabajador {
    String nombre;
    int edad;
    float altura;
    
    //Constructor que toma una variable de tipo String como parámetro y la asigna a la variable "nombre" del objeto
    public Trabajador(String nombre){
        this.nombre = nombre;
    }
    //Método que devuelve un String con el nombre del objeto Trabajador
    String consulta_Nombre(){
        return nombre;
 }
    //Método que recibe un String como parámetro y cambia la variable "nombre" del objeto
    void cambia_Nombre(String nom){
        nombre=nom;
 }
}
