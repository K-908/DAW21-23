/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prog10;


import java.util.List;
import java.util.Scanner;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

/**
 *
 * @author Gogloglo
 */
public class Diccionario {
    
    private EntityManagerFactory emf = Persistence.createEntityManagerFactory("$objectdb/db/BBDD.odb");;
    private Scanner reader = new Scanner(System.in);
    
    public Diccionario(){
        
    }
    
    public void buscarPalabra(String es){
        EntityManager em = emf.createEntityManager();
        
        
        es = "%"+es+"%";
        Query query = em.createQuery("SELECT p FROM Palabra p WHERE p.es LIKE :es");
        query.setParameter("es", es);
        List<Palabra> resultados = query.getResultList();
        if(!resultados.isEmpty()){
            for(int i=0;i<resultados.size();i++){
                em.getTransaction().begin();
                Palabra palabra =resultados.get(i);
                palabra.visto();
                System.out.println(palabra.toString());
                em.getTransaction().commit();
                
            }
            
            em.close();
        } else{
            em.close();
            System.out.println("No se ha encontrado la palabra");
        }
    }
    
    
    
    public void guardarPalabra(Palabra palabra){
        EntityManager em = emf.createEntityManager();
        int nextId = getProximoId();
        String nombrePalabra = palabra.getEs();
        try{
        em.getTransaction().begin();
        Query query = em.createQuery("SELECT p FROM Palabra p WHERE p.es = :nombrePalabra");
        query.setParameter("nombrePalabra", nombrePalabra);
        List<Palabra> resultados = query.getResultList();
        if(resultados.isEmpty()){
            palabra.setId(nextId);
            em.persist(palabra);
            em.getTransaction().commit();
            em.close();
        } else{
            em.close();
            System.out.println("Esa palabra ya está en el diccionario");
        }
        }catch(Exception e){
            System.out.println("Error"+e.getMessage());
            e.printStackTrace();
        }
    }
    
    public void listarPalabras(){
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        Query query = em.createQuery("SELECT p FROM Palabra p");
        List<Palabra> resultados = query.getResultList();
        System.out.println("Palabras en el diccionario: ");
        for(int i=0;i<resultados.size();i++){
            System.out.println(resultados.get(i).toString());
        }
    }
    
    public int getProximoId(){
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        Query query = em.createQuery("SELECT p FROM Palabra p");
        List<Palabra> resultados = query.getResultList();
        int proximo = (int)resultados.get(resultados.size()-1).getId()+1;
        em.close();
        return proximo;
    }
    
    public void anadirTerminos(String nombrePalabra){
        EntityManager em = emf.createEntityManager();
        String idioma;
        while(true){
            System.out.println("Código de dioma de la traducción (2 letras): ");
            idioma = reader.nextLine();
            if(idioma.length()>2){
                System.out.println("El código de idioma debe contener 2 letras como mucho (en, fr, de...).");
            } else{
                break;
            }
        }
        System.out.println("Traducción: ");
        String traduccion = reader.nextLine();
        
        
        em.getTransaction().begin();
        try{
            Query query = em.createQuery("SELECT p FROM Palabra p WHERE p.es = :es");
            query.setParameter("es", nombrePalabra);
            Palabra palabra = (Palabra)query.getSingleResult();
            palabra.addTraduccion(idioma, traduccion);
            System.out.println("Traducción añadida.");
            em.getTransaction().commit();
            em.close();
        }catch(Exception e){
            System.out.println("Error al introducir la traducción.");
            System.out.println(e.getMessage());
            e.printStackTrace();
            em.close();
        }
    }
    
    public void borrarPalabra(String nombrePalabra){
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        Query query = em.createQuery("SELECT p FROM Palabra p WHERE p.es = :es");
        query.setParameter("es", nombrePalabra);
        List<Palabra> resultados = query.getResultList();
        if(resultados.size()==1){
            em.remove(resultados.get(0));
            System.out.println("Palabra borrada");
            em.getTransaction().commit();
            em.close();
        } else{
            em.close();
            System.out.println("No se ha encontrado la palabra");
        }
    }
}
