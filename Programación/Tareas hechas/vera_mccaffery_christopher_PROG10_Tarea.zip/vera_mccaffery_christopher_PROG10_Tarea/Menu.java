/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prog10;

import java.util.Scanner;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author Gogloglo
 */
public class Menu {
    private EntityManagerFactory emf;  
    private Scanner reader = new Scanner(System.in);;
    
    
    public Menu(){
        this.emf = Persistence.createEntityManagerFactory("$objectdb/db/BBDD.odb");
    }
    
    public void mostrarOpciones(){
        System.out.println("----Diccionario----");
        System.out.println("\t1. Añadir palabra");
        System.out.println("\t2. Añadir términos");
        System.out.println("\t3. Buscar palabra");
        System.out.println("\t4. Mostrar todo el diccionario");
        System.out.println("\t5. Borrar palabra");
        System.out.println("\t0. Salir del programa");
    }
    
    public void iniciar(){
        Diccionario diccionario = new Diccionario();
        boolean continuar = true;
        while(true){
            
            if(!continuar){
                break;
            }
            mostrarOpciones();
            
            int input;
            try{
                input = Integer.parseInt(reader.nextLine());
                switch(input){
                case 1:
                    System.out.println("Introduzca el nombre de la palabra: ");
                    String nombrePalabra = reader.nextLine();
                    Palabra palabra = new Palabra(nombrePalabra);
                    diccionario.guardarPalabra(palabra);
                    System.out.println("Palabra: "+nombrePalabra);
                    break;
                case 2: 
                    System.out.println("Palabra a la que añadirle traducciones");
                    String nombrePalabra2 = this.reader.nextLine();
                    diccionario.anadirTerminos(nombrePalabra2);
                    break;
                case 3: 
                    System.out.println("Palabra a buscar: ");
                    String palabraBuscar = reader.nextLine();
                    diccionario.buscarPalabra(palabraBuscar);
                    break;
                case 4: 
                    diccionario.listarPalabras();
                    break;
                case 5: 
                    System.out.println("Palabra a borrar");
                    String palabraBorrar = reader.nextLine();
                    diccionario.borrarPalabra(palabraBorrar);
                    break;
                case 0: 
                    continuar = false;
                    break;
            }
            } catch(NumberFormatException e){
                System.out.println("Introduzca un número entre el 0 y el 5.");
            }
            
            

        }
    }
}