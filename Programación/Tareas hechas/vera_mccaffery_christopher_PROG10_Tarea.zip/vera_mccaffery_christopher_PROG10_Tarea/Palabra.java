/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prog10;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import javax.persistence.*;

/**
 *
 * @author Gogloglo
 */
@Entity 
public class Palabra implements Serializable  {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    private String es;
    private HashMap<String, String> traducciones;
    private int vecesVisto;
    
    
    public Palabra(){
        
    }
    
    public Palabra(String es){
        this.es = es;
        this.traducciones = new HashMap<>();
        this.vecesVisto = 0;
    }
    
    public void listarIdiomas(){
        if(!this.traducciones.isEmpty()){
            System.out.println("Idiomas a los que se ha traducido la palabra "+this.es);
            for(HashMap.Entry<String, String> set: traducciones.entrySet()){
                System.out.print(set.getKey()+"\t");
            }
        } else{
            System.out.println("La palabra "+this.es+" no tiene traducciones.");
        }

    }
    
    public void addTraduccion(String idioma, String traduccion){
        try{
            this.traducciones.putIfAbsent(idioma, traduccion);
        } catch(Exception e){
            System.out.println("Traducción ya presente");
        }
    }
    
    public void visto(){
        this.vecesVisto++;
    }
    
    public String getTraduccion(String idioma){
        return this.traducciones.get(idioma);
    }
    
    public void borrarTraduccion(String idioma){
        this.traducciones.remove(idioma);
    }
    
    public void mostrarPalabra(){
        for(HashMap.Entry<String, String> set: traducciones.entrySet()){
            System.out.println(set.getKey()+" - "+set.getValue());
        }
        this.vecesVisto++;
    }
    
    
    public String getEs(){
        return this.es;
    }
    
    public void setEs(String es){
        this.es = es;
    }
    
    public void setId(long id){
        this.id = id;
    }

    public long getId() {
        return id;
    }
    
    public String toString(){
        String texto = "Palabra: "+this.es+"\tVeces visto: "+this.vecesVisto+"\tID: "+this.id+"\tTraducciones: ";
        if(traducciones!=null){
            for (Map.Entry<String, String> set : traducciones.entrySet()) {
             texto+="\n\t\t"+set.getKey()+": "+set.getValue();
        }
        }
        texto+="\n\n";
        return texto;
    }


}
