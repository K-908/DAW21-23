import java.io.*;
import java.io.Serializable;

public class Cliente implements Serializable {
    private String nif;
    private String nombre;
    private String telefono;
    private String direccion;
    private double deuda;

    public Cliente(String nif, String nombre, String telefono, String direccion, double deuda) {
        this.nif = nif;
        this.nombre = nombre;
        this.telefono = telefono;
        this.direccion = direccion;
        this.deuda = deuda;
    }

    public String getNif() {
        return nif;
    }

    public void setNif(String nif) {
        this.nif = nif;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public double getDeuda() {
        return deuda;
    }

    public void setDeuda(double deuda) {
        this.deuda = deuda;
    }

    @Override
    public String toString(){
        String deuda = String.format("%.2f", this.deuda);
        return "Nombre: "+this.nombre+" NIF: "+this.nif+" Teléfono: "+this.telefono+" Dirección: "+this.direccion+" Deuda: "+deuda;
    }

}
