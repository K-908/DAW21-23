import java.util.Scanner;

public class Menu {
private static Scanner reader = new Scanner(System.in);
    public static void printMenu(){
        System.out.println("Elija el número correspondiente:");
        System.out.println("1: Añadir clientes");
        System.out.println("2: Listar clientes");
        System.out.println("3: Buscar clientes");
        System.out.println("4: Borrar cliente");
        System.out.println("5: Borrar fichero de clientes completamente");
        System.out.println("0: Salir de la aplicación");
    }

    public static void runMenu(){
        boolean run = true;
        while(run){
            printMenu();
            int input = reader.nextInt();

            switch(input){
                case 1: Fichero.nuevoCliente(); break;
                case 2: Fichero.listarClientes(); break;
                case 3: {
                    System.out.println("Introduce el nombre del cliente que quieres buscar:");
                    Fichero.buscarCliente();
                    break;
                }
                case 4: {
                    System.out.println("Introducee el nombre del cliente que quieres borrar:");
                    Fichero.borrarCliente();
                    break;
                }
                case 5: {
                    Fichero.borrarFichero();
                    break;
                }

                case 0: {
                    run = false;
                    break;
                }
                default:
                    System.out.println("Opción incorrecta");
                    break;
            }
        }
    }
}
