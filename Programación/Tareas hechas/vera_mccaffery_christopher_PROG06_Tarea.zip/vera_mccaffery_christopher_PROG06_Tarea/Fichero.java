import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.*;

public class Fichero {

    private static  ArrayList<Cliente> clientes = new ArrayList<>();
    static  Scanner reader = new Scanner(System.in);



    public static void escribir(){
        try{
            ObjectOutputStream escritor = new ObjectOutputStream(new FileOutputStream("clientes.dat"));
            escritor.writeObject(clientes);
            escritor.close();
        }catch(Exception e){
            System.out.println("Error al escribir en el fichero");
        }
    }

    public static void leer(){
        try{
            ObjectInputStream lector = new ObjectInputStream(new FileInputStream("clientes.dat"));
            clientes = (ArrayList<Cliente>) lector.readObject();
            lector.close();
        }catch(Exception e){
            System.out.println("Error al leer el fichero");
        }
    }

    public static void nuevoCliente() {
        leer();
        System.out.println("Nombre y apellidos del cliente: ");
        //Pedimos nombre y comprobamos con Regex que se ha introducido un nombre y apellidos válido
        String nombre;
        while (true) {
            nombre = reader.nextLine();
            if (nombre.matches("^[\\w]+[\\s][\\w]+[\\s]?[\\w]?$")) {
                break;
            } else {
                System.out.println("Nombre incorrecto");
            }
        }
        System.out.println("Introduzca el NIF del cliente (12345678A)");
        String nif;
        while (true) {
            nif = reader.nextLine();
            if (nif.matches("^[\\d]{8}[\\w]{1}$")) {
                break;
            } else {
                System.out.println("NIF incorrecto (12345678A)");
            }
        }
        System.out.println("Introduzca el teléfono del cliente (123456789)");
        String telefono;
        while (true) {
            telefono = reader.nextLine();
            if (telefono.matches("^[\\d]{9}$")) {
                break;
            } else {
                System.out.println("Teléfono incorrecto. Deben ser 9 dígitos sin guiones ni espacios");
            }
        }

        System.out.println("Introduce la dirección");
        String direccion = reader.nextLine();
        System.out.println("Introduce la cantidad adeudada");
        double deuda;
        while (true) {
            String deudaString = reader.nextLine();
            if(deudaString.matches("^[\\d]+([\\.][\\d]{1,2})?$")){
                deuda = Double.parseDouble(deudaString);
                break;
            } else{
                System.out.println("Cantidad introducida incorrecta.");
            }
        }

        clientes.add(new Cliente(nif, nombre, telefono, direccion, deuda));
        escribir();
    }

    public static void listarClientes(){
        leer();
        for(Cliente c : clientes){
            System.out.println(c.toString());
        }
    }

    public static void buscarCliente(){
        String nombre = reader.nextLine();
        leer();
        int encontrado = 0;
        for(Cliente c : clientes){
            if(c.getNombre().toLowerCase().equals(nombre.toLowerCase())){
                encontrado++;
            }
        }
        if(encontrado == 0){
            System.out.println("No se ha encontrado el cliente.");
        } else{
            System.out.println("El cliente se encuentra en el fichero");
        }
    }

    public static void borrarCliente(){
        String nif = reader.nextLine();
        leer();
        for(Cliente c:clientes){
            if(c.getNif().toLowerCase().equals(nif.toLowerCase())){
                clientes.remove(c);
                System.out.println("Cliente borrado");
            }
        }
        if(clientes.size()>0){
            escribir();
        } else{
            File archivo = new File("clientes.dat");
            archivo.delete();
        }
    }

    public static void borrarFichero(){
        boolean borrado = new File("clientes.dat").delete();
        if(borrado){
            System.out.println("El archivo se ha borrado correctamente");
        } else{
            System.out.println("No se ha podido borrar el archivo");
        }
    }
}
