public abstract class Deporte {
    private static String nombre;
    private static int fechaCreacion;

    public Deporte(String nombre, int fechaCreacion){
        this.nombre= nombre;
        this.fechaCreacion=fechaCreacion;
    }

    public static String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public static int getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(int fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    public String getInfo(){
        return "Nombre: "+this.nombre+"\nAño de creación: "+this.fechaCreacion;
    }
}
