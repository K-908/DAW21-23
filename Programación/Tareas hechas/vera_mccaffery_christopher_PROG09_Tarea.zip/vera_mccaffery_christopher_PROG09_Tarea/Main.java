public class Main {
    public static void main(String[] args) {
        Fitness spinning = new Fitness("Spinning", 2023, "Fuerte", 25);
        Fitness crossfit = new Fitness("Crossfit", 1906, "Baja", 180);
        Wellness yoga = new Wellness("Yoga", 1980, "Toalla", "Avanzado");
        Usuario pepe = new Usuario("1234", "Pepe", "Martinez Lopez", "01/01/1970");
        pepe.altaDeporte(spinning);
        pepe.altaDeporte(crossfit);
        pepe.altaDeporte(yoga);
        pepe.mostrarDeportes();
        pepe.bajaDeporte(yoga);
    }
}