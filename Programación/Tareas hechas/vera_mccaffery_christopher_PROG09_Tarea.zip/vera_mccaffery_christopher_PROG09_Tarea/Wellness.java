public class Wellness extends Deporte{
    private String materialPrincipal;
    private String dificultad;

    public Wellness(String nombre, int fechaCreacion, String materialPrincipal, String dificultad) {
        super(nombre, fechaCreacion);
        this.materialPrincipal=materialPrincipal;
        this.dificultad=dificultad;
    }

    public String getMaterialPrincipal() {
        return materialPrincipal;
    }

    public void setMaterialPrincipal(String materialPrincipal) {
        this.materialPrincipal = materialPrincipal;
    }

    public String getDificultad() {
        return dificultad;
    }

    public void setDificultad(String dificultad) {
        this.dificultad = dificultad;
    }

    @Override
    public String getInfo(){
        return "Nombre: "+getNombre()+"\nAño de creación: "+getFechaCreacion()
                +"\nMateral principal: "+getMaterialPrincipal()+"\nDificultad: "+getDificultad();
    }
}
