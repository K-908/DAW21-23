public class Fitness extends Deporte{
    private String intensidad;
    private int alumnosPorClase;

    public Fitness(String nombre, int fechaCreacion, String intensidad, int alumnosPorClase) {
        super(nombre, fechaCreacion);
        this.intensidad=intensidad;
        this.alumnosPorClase=alumnosPorClase;
    }

    public String getIntensidad() {
        return intensidad;
    }

    public void setIntensidad(String intensidad) {
        this.intensidad = intensidad;
    }

    public int getAlumnosPorClase() {
        return alumnosPorClase;
    }

    public void setAlumnosPorClase(int alumnosPorClase) {
        this.alumnosPorClase = alumnosPorClase;
    }

    @Override
    public String getInfo(){
        return "Nombre: "+getNombre()+"\nAño de creación: "+getFechaCreacion()
                +"\nIntensidad: "+getIntensidad()+"\nNúmero de alumnos por clase: "+getAlumnosPorClase();
    }

}
