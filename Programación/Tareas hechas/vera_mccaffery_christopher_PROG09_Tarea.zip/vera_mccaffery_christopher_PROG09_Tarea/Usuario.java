import java.util.ArrayList;

public class Usuario implements Gimnasio{
    private String id;
    private String nombre;
    private String apellidos;
    private String fechaNacimiento;
    private ArrayList<Deporte> deportes;
    private static int usuariosCreados = 0;

    public Usuario(String id, String nombre, String apellidos, String fechaNacimiento){
        this.id=id;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.fechaNacimiento = fechaNacimiento;
        this.deportes = new ArrayList<Deporte>();
        usuariosCreados++;
    }
    @Override
    public void altaDeporte(Deporte deporte){
        if(this.deportes.size() <3){
            deportes.add(deporte);
        } else{
            System.out.println("No se puede estar apuntado a más de tres deportes.");
        }
    }
    @Override
    public void mostrarDeportes(){
        System.out.println("Mostrando deportes del usuario "+this.nombre+" "+this.apellidos+":");
        System.out.println("-------------------------------------------");
        for(Deporte deporte:deportes){
            System.out.println(deporte.getInfo()+"\n");
        }
        System.out.println("-------------------------------------------");
    }

    @Override
    public void bajaDeporte(Deporte deporte){
        if(this.deportes.contains(deporte)){
            this.deportes.remove(deporte);
        } else{
            System.out.println("El usuario no está apuntado a "+deporte.getNombre());
        }
    }


}
