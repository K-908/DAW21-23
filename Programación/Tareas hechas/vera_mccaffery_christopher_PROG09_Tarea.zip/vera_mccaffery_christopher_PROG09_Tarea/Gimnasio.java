public interface Gimnasio {
    public void altaDeporte(Deporte deporte);
    public void mostrarDeportes();
    public void bajaDeporte(Deporte deporte);
}
