import java.util.Scanner;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author gogloglo
 */
public class ejercicio7 {
    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);
        
        System.out.println("Introduce 5 dígitos: ");
        while(true){
            int digitos = Integer.parseInt(reader.nextLine());
            if(digitos>99999 || digitos <10000){
                System.out.println("Deben ser exactamente 5 dígitos. Inténtelo de nuevo");
            } else{
                String digitosString = String.valueOf(digitos);
                for(int i=0;i<5;i++){
                    System.out.print(digitosString.charAt(i)+" ");
                }
                break;
            }
        }
    }
}
