/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.test;



/**
 * @code 
 * @author Christopher Vera McCaffery
 */
//Aquí comienza la clase Main
public class ejerciciovariables {
    //Aquí comienza el método main
    public static void main(String args[]){
        //O está casado o no, 1 byte
         boolean casado;
         //Short sólo llega hasta 32767, así que vamos al siguiente valor numérico más pequeño, int
         final int MAXIMO = 999999;
         //Sólo necesitamos un número del 1 al 7, así que el valor más pequeño, Byte, nos vale
         byte diasem;
         //Byte sólo llega a 127, así que elijo el siguiente más pequeño que sería short
         short diaanual;
         //Las respuestas normalmente son "M"/"F", así que con char nos vale
         char sexo;
         //Ahora mismo epoch (tiempo desde 01/01/1970 hasta ahora) es 1.666.039.041.316, con int no nos daría
         long miliseg;
         //El tipo de dato más pequeño que acepta decimales
         double totalfactura;
         //int sólo llega a 2.147.483.647, unos 4.000 millones menos que la población actual de la Tierra
         long poblacion;

         //Asignamos valores a las variables, salvo la constante que ya está declarada.
         casado = true;
         diasem = 1;
         diaanual = 300;
         sexo = 'M';
         miliseg = 1298332800000L;
         totalfactura = 10350.678;
         poblacion = 6775235741L;
         
         
         
         //Usando sólo la orden println:
         
         System.out.println("El valor de la variable casado es "+casado);
         System.out.println("El valor de la variable MAXIMO es "+MAXIMO);
         System.out.println("El valor de la variable diaSemana es "+diasem);
         System.out.println("El valor de la variable diaAnual es "+diaanual);
         System.out.println("El valor de la variable miliseg es "+miliseg);
         System.out.println("El valor de la variable totalfactura es "+totalfactura);
         System.out.println("El valor de la variable poblacion es "+poblacion);
         System.out.println("El valor de la variable sexo es "+sexo);
         System.out.println("---------------------------------------------");
         //Usando sólo la orden print:
         
         System.out.print("El valor de la variable casado es "+casado+"\n");
         System.out.print("El valor de la variable MAXIMO es "+MAXIMO+"\n");
         System.out.print("El valor de la variable diaSemana es "+diasem+"\n");
         System.out.print("El valor de la variable diaAnual es "+diaanual+"\n");
         System.out.print("El valor de la variable miliseg es "+miliseg+"\n");
         System.out.print("El valor de la variable totalfactura es "+totalfactura+"\n");
         System.out.print("El valor de la variable poblacion es "+poblacion+"\n");
         System.out.print("El valor de la variable sexo es "+sexo+"\n");
         System.out.println("---------------------------------------------");
         
         //Usando sólo la orden printf:
         System.out.printf("El valor de la variable casado es %b%n",casado);
         System.out.printf("El valor de la variable MAXIMO es %d%n",MAXIMO);
         System.out.printf("El valor de la variable diaSemana es %d%n",diasem);
         System.out.printf("El valor de la variable diaAnual es %d%n",diaanual);
         System.out.printf("El valor de la variable miliseg es %d%n",miliseg);
         System.out.printf("El valor de la variable totalfactura es %.3f%n",totalfactura);
         System.out.printf("El valor de la variable poblacion es %d%n",poblacion);
         System.out.printf("El valor de la variable sexo es %c%n",sexo);
         
         
    }//Fin del método main
    
}//Fin de la clase Main
