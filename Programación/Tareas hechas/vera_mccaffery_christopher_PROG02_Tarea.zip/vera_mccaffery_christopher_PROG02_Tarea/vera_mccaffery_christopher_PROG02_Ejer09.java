
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author gogloglo
 */
public class ejercicio9 {

    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);
        int[] dias = new int[]{31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
        String[] meses = new String[]{"Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"};

        System.out.println("Introduce el número del mes: ");
        int mes = (Integer.parseInt(reader.nextLine()))-1;
        
        if (mes >= 0 && mes < 12) {
            System.out.println("El mes "+meses[mes]+" tiene "+dias[mes]+" dias.");
        } else {
            System.out.println("Mes introducido incorrecto");
        }
    }
}
