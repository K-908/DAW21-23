public class ejerciciovariables {

    public static void main(String args[]){
        //O está casado o no, 1 byte
         boolean casado;
         //Short sólo llega hasta 32767, así que vamos al siguiente valor numérico más pequeño, int
         final int MAXIMO = 999999;
         //Sólo necesitamos un número del 1 al 7, así que el valor más pequeño, Byte, nos vale
         byte diasem;
         //Byte sólo llega a 127, así que elijo el siguiente más pequeño que sería short
         short diaanual;
         //Las respuestas normalmente son "M"/"F", así que con char nos vale
         char sexo;
         //Ahora mismo epoch (tiempo desde 01/01/1970 hasta ahora) es 1.666.039.041.316, con int no nos daría
         long miliseg;
         //El tipo de dato más pequeño que acepta decimales
         double totalfactura;
         //int sólo llega a 2.147.483.647, unos 4.000 millones menos que la población actual de la Tierra
         long poblacion;

    }
}
