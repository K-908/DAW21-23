import java.util.Scanner;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author gogloglo
 */
public class ejercicio6 {
    public static void main(String[] args) {
        
        Scanner reader = new Scanner(System.in);
        System.out.print("Introduce el primer número: ");
        int x = Integer.parseInt(reader.nextLine());
        System.out.print("\nIntroduce el segundo número: ");
        int y = Integer.parseInt(reader.nextLine());
        
        if(x%y==0){
            System.out.println(y+" es múltiplo de "+x+". Resultado: "+(x/y));
        } else{
            System.out.println(y+" no es múltiplo de "+x+".");
        }
        
    }
}
