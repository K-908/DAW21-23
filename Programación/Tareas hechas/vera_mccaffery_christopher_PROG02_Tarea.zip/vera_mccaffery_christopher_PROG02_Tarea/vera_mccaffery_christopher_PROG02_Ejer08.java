import java.util.Scanner;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author gogloglo
 */
public class ejercicio8 {
    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);
        
        System.out.println("Introduce las horas: ");
        int H = Integer.parseInt(reader.nextLine());
        System.out.println("Introduce los minutos: ");
        int M = Integer.parseInt(reader.nextLine());
        System.out.println("Introduce los segundos: ");
        int S = Integer.parseInt(reader.nextLine());
        if(H>23||H<0||M>59||M<0||S>59||S<0){
            System.out.println("Error, formato incorrecto.");
        } else{
            System.out.println("Hora introducida correctamente.");
        }
    }
}
