
import java.io.*;
import java.util.ArrayList;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author Gogloglo
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        VentanaPrincipal principal = new VentanaPrincipal();
        principal.setVisible(true);
        /*Fichero.leer();
        ArrayList<Habitacion> habitaciones = Fichero.getHabitaciones();
        for(Habitacion hab:habitaciones){
            System.out.println(hab.toString());
        }*/
    }
    }
  
