import java.io.*;
import java.util.ArrayList;

public class Fichero {
    private static ArrayList<Habitacion> habitaciones = new ArrayList<>();

    public static void escribir(){
        try{
            ObjectOutputStream escritor = new ObjectOutputStream(new FileOutputStream("habitaciones.ser"));
            escritor.writeObject(habitaciones);
            escritor.close();
        }catch(Exception e){
            System.out.println("Error al escribir en el fichero");
        }
    }

    public static void leer(){
        try{
            ObjectInputStream lector = new ObjectInputStream(new FileInputStream("habitaciones.ser"));
            habitaciones = (ArrayList<Habitacion>) lector.readObject();
            lector.close();
        }catch(Exception e){
            System.out.println("Error al leer el fichero");
        }
        
        if(habitaciones.isEmpty()||habitaciones==null){
            crearHabitaciones();
            escribir();
        }
    }
    
    public static ArrayList<Habitacion> getHabitaciones(){
        return habitaciones;
    }
    
    public static void crearHabitaciones(){
        for(int i=0;i<10;i++){
        String nombre = "Habitacion "+(i+1);
        int precio;
        if(i<5){
            precio = 100;
        } else{
            precio = 150;
        }
        habitaciones.add(new Habitacion(nombre, precio));
        }
    }
    
        public static void actualizarHabitaciones(Habitacion habitacion){
        leer();
            for(Habitacion hab:habitaciones){
            if(hab.getNombre().equals(habitacion.getNombre())){
                int index=habitaciones.indexOf(hab);
                habitaciones.set(index, habitacion);
            }
        }
            for(Habitacion hab:habitaciones){
            System.out.println(hab.toString());
        }
        escribir();
    }
    

}
