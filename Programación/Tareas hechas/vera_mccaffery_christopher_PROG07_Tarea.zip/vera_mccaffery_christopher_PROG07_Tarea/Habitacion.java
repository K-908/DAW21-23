import java.io.Serializable;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Habitacion implements Serializable{
    private String nombre;
    private Boolean disponible;
    private Huesped huesped;
    private int precio;
    private LocalDate ingreso;

    public Habitacion(String nombre, int precio) {
        this.nombre = nombre;
        this.precio = precio;
        this.disponible = true;
        this.huesped = null;
        this.ingreso = null;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Boolean getDisponible() {
        return disponible;
    }

    public void setDisponible(Boolean disponible) {
        this.disponible = disponible;
    }

    public Huesped getHuesped() {
        return huesped;
    }

    public void setHuesped(Huesped huesped) {
        this.huesped = huesped;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public LocalDate getIngreso() {
        return ingreso;
    }

    public void setIngreso(LocalDate ingreso) {
        this.ingreso = ingreso;
    }
    
    public boolean ocuparHabitacion(Huesped huesped, LocalDate fecha){
        
        if(this.getDisponible()){
            this.disponible=false;
            this.huesped = huesped;
            this.ingreso=fecha;
            return true;
        }
        return false;
    }
    


    @Override
    public String toString(){
        return "Nombre: "+this.nombre+"\n\t Precio: "+this.precio+"\n\t Disponible: "+this.disponible;
    }
}
