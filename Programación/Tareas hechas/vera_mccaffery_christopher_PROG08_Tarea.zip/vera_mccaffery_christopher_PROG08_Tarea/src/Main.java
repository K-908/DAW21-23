import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException, SAXException, TransformerException, ParserConfigurationException {
        //Creamos un objeto EscribirClientes. Esto automáticamente nos pide datos
        EscribirClientes escribirClientess = new EscribirClientes();
        //Creamos un objeto de LeerClientes. Esto automáticamente nos muestra los datos
        LeerClientes leerClientes = new LeerClientes();
        leerClientes.mostrarMayor();

    }
}