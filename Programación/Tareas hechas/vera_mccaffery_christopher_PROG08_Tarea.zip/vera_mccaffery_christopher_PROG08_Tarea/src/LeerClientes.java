import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;
//Constructor LeerClientes. Llamar al constructor automáticamente nos muestra los datos que tengamos almacenados.
public class LeerClientes {
    public LeerClientes() throws IOException, SAXException, ParserConfigurationException {
        DocumentBuilderFactory factory1 = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder1 = factory1.newDocumentBuilder();
        Document documentoLectura = builder1.parse(new File("empresa.xml"));

        //Añadimos todos los elementos que tengan el tag "cliente" a un array de nodos
        NodeList listaClientes = documentoLectura.getElementsByTagName("cliente");
        System.out.println("LISTA DE CLIENTES:\n");
        //recorremos el Array, creando listas de nodos con los elementos de cada nodo padre "cliente"
        for(int i=0;i<listaClientes.getLength();i++){
            Node nodo = listaClientes.item(i);
            if(nodo.getNodeType()==Node.ELEMENT_NODE){
                Element e = (Element) nodo;
                NodeList hijos = e.getChildNodes();
                //Luego recorremos todos los elementos hijos de cada nodo "cliente" y lo mostramos por pantalla
                for(int j=0;j<hijos.getLength();j++){
                    Node hijo = hijos.item(j);
                    if(hijo.getNodeType()==Node.ELEMENT_NODE){
                        Element eHijo = (Element) hijo;
                        System.out.println(eHijo.getNodeName()+" - "+eHijo.getTextContent());
                    }
                }
                System.out.println("-------------");
            }
        }
    }
    //Método que muestra el cliente con la mayor deuda.
    public void mostrarMayor() throws ParserConfigurationException, IOException, SAXException {
        DocumentBuilderFactory factory1 = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder1 = factory1.newDocumentBuilder();
        Document documentoLectura = builder1.parse(new File("empresa.xml"));
        //buscamos todos los elementos con el tag "deuda"
        NodeList listaDeudas = documentoLectura.getElementsByTagName("deuda");
        //creamos 2 variables de control, una para ir llevando la cuenta de la deuda más alta y otro con
        //el nodo "cliente" al que pertenece ese elemento "deuda"
        double maximaDeuda = 0;
        Node deudor = null;
        System.out.println("El mayor deudor es:\n");
        for(int i=0;i<listaDeudas.getLength();i++){
            String valorEnString = listaDeudas.item(i).getTextContent();
            double valorDeuda = Double.parseDouble(valorEnString);
            //si el valor del campo "deuda" es mayor que el de la variable "maximaDeuda"
            if(valorDeuda>=maximaDeuda){
                //la variable "maximaDeuda" actualiza su valor al del elemento "deuda"
                maximaDeuda = valorDeuda;
                //y añadimos al elemento padre al nodo "deudor"
                deudor = listaDeudas.item(i).getParentNode();
            }
        }
        //una vez hemos recorrido todos los elementos "deuda", pasaremos a recorrer el nodo "cliente"
        //que tenga la deuda más alta.
        NodeList datosDeudor = deudor.getChildNodes();
        for(int j=0;j<datosDeudor.getLength();j++){
            Node hijo = datosDeudor.item(j);
            if(hijo.getNodeType()==Node.ELEMENT_NODE){
                Element eHijo = (Element) hijo;
                System.out.println(eHijo.getNodeName()+" - "+eHijo.getTextContent());
            }
        }
    }
}
