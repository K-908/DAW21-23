import org.w3c.dom.*;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.util.Scanner;
public class EscribirClientes {
    //Creamos los distintos objetos que necesitaremos para poder trabajar con documentos XML
    private DocumentBuilderFactory factory;
    private Scanner reader = new Scanner(System.in);
    private DocumentBuilder builder;
    private DOMImplementation implementation;
    private Document documento;
    //Constructor sin parámetros. Cuando se inicia el constructor llama al método introducirDatos()
    public EscribirClientes() throws TransformerException {
         this.factory = DocumentBuilderFactory.newInstance();
        try {
            builder = factory.newDocumentBuilder();
        } catch (ParserConfigurationException e) {
            throw new RuntimeException(e);
        }

        this.implementation = builder.getDOMImplementation();
        this.documento = implementation.createDocument(null, "empresa", null);
        introducirDatos();
    }
    //Método que nos pide que introduzcamos los datos para añadir al documento XML.
    //Comprueba la validez de los datos con Regex
    public void introducirDatos() throws TransformerException {
        Element clientes = this.documento.createElement("clientes");
        while(true){
            Element cliente = this.documento.createElement("cliente");

            while(true){
                System.out.println("Introduzca el nif del cliente: ");
                String inputNif = reader.nextLine();

                if(inputNif.matches("^[0-9]{8}(\\-)?[A-Za-z]$")){
                    Element elementoNif = this.documento.createElement("nif");
                    Text textoNif = this.documento.createTextNode(inputNif);
                    elementoNif.appendChild(textoNif);
                    cliente.appendChild(elementoNif);
                    break;
                } else{
                    System.out.println("NIF incorrecto. Debe tener 8 dígitos seguidos de una letra");
                }
            }
            while(true){
                System.out.println("Introduzca el nombre del cliente: ");
                String inputNombre = reader.nextLine();
                if(inputNombre.trim().matches("^[A-Za-z]{2,}\\s[A-Za-z]{2,}(\\s[A-Za-z]{2,})?$")) {
                    Element elementoNombre = this.documento.createElement("nombre");
                    Text textoNombre = this.documento.createTextNode(inputNombre);
                    elementoNombre.appendChild(textoNombre);
                    cliente.appendChild(elementoNombre);
                    break;
                } else{
                    System.out.println("Nombre incorrecto. No puede incluir números ni caracteres especiales");
                }
            }

            while(true){
                System.out.println("Introduzca el teléfono del cliente: ");
                String inputTlf = reader.nextLine();
                String inputTlfBien = inputTlf.replaceAll("[^0-9]", "");
                if(inputTlfBien.matches("^[0-9]{9}$")){
                    Element elementoTlf = this.documento.createElement("telefono");
                    Text textoTlf = this.documento.createTextNode(inputTlfBien);
                    elementoTlf.appendChild(textoTlf);
                    cliente.appendChild(elementoTlf);
                    break;
                } else{
                    System.out.println("Teléfono incorrecto. Debe contener 9 dígitos.");
                }
            }

            System.out.println("Introduzca la dirección del cliente: ");
            Element elementoDireccion = this.documento.createElement("direccion");
            Text textoDireccion = this.documento.createTextNode(reader.nextLine());
            elementoDireccion.appendChild(textoDireccion);
            cliente.appendChild(elementoDireccion);

            while(true){
                System.out.println("Introduzca la deuda del cliente: ");
                String inputDeuda = reader.nextLine();
                if(inputDeuda.matches("^[0-9]+([.][0-9]{1,2})?$")){
                    Element elementoDeuda = this.documento.createElement("deuda");
                    Text textoDeuda = this.documento.createTextNode(inputDeuda);
                    elementoDeuda.appendChild(textoDeuda);
                    cliente.appendChild(elementoDeuda);
                    break;
                } else{
                    System.out.println("Cantidad introducida incorrecta.");
                }
            }
            clientes.appendChild(cliente);
            System.out.println("Escriba X para terminar, o cualquier otra cosa para introducir otro cliente.");
            String opcion = reader.nextLine();
            if(opcion.equals("X")){
                break;
            }
        }
        documento.getDocumentElement().appendChild(clientes);
        Source source = new DOMSource(documento);
        Result result = new StreamResult(new File("empresa.xml"));

        Transformer transformer = TransformerFactory.newInstance().newTransformer();

        transformer.transform(source, result);
    }
}
