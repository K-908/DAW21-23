//importamos la utilidad Scanner para poder introducir datos por teclado.
import java.util.Scanner;
//importamos la utilidad Exception para poder lanzar excepciones
import java.lang.Exception;
public class Main {
    public static void main(String[] args) throws Exception{
        //Creamos un objeto Scanner
        Scanner reader = new Scanner(System.in);
        //Rodeamos el código dentro de un bloque try/catch para que lance una excepción si los números introducidos no son correctos
        try{
            //Pedimos la usuario que introduzca la cantidad de dinero invertida
            System.out.println("Dinero inicial: ");
            //Creamos una variable con el dinero invertido
            double dinero = reader.nextInt();
            //Pedimos al usuario que introduzca la rentabilidad de la inversión
            System.out.println("Rentabilidad (%): ");
            //Creamos una varaible con el valor de la rentabilidad
            double rentabilidad = reader.nextInt();
            /*
             * La rentabilidad compuesta añade el porcentaje de rentabilidad
             * al dinero que se tiene cada mes, así que usamos un bucle para
             * que calcule la rentabilidad 12 veces, una vez al mes, utilizando el
             * dinero total del mes anterior como base
             * */
            for(int i=0;i<12;i++){
                dinero+=dinero*(rentabilidad/100);
            }
            System.out.printf("Dinero tras un año: %.2f€",dinero);
        } catch(Exception e){
            System.out.println("Número introducido incorrecto: "+e);
        }
    }

}
