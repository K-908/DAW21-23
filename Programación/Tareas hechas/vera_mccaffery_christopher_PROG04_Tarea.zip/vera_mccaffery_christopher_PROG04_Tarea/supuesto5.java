//importamos la utilidad Scanner para poder introducir datos por teclado.
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        //Creamos un objeto Scanner
        Scanner reader = new Scanner(System.in);
        //Creamos una variable que guarde la clave
        String clave = "Eureka";
        //Creamos un bucle que pedirá la contraseña hasta que se introduzca correctamente
        while(true){
            //Se pide al usuario que introduzca la contraseña
            System.out.println("Escribe la contraseña: ");
            //Se guarda la clave introducia en una variable
            String intento = reader.nextLine();
            //Si la contraseña introducida es correca
            if(clave.equals(intento)){
                //Se indica que es correcta
                System.out.println("Contraseña correcta.");
                //Y se corta el bucle
                break;
                //Si no es correcta
            } else{
                //Se indica que es incorrecta y el bucle se repite
                //Volveríamos a la línea 12
                System.out.println("Contraseña incorrecta.");
            }
        }
    }
}
