//importamos la utilidad Scanner para poder introducir datos por teclado.
import java.util.Scanner;
//importamos la utilidad Exception para poder lanzar excepciones
import java.lang.Exception;
public class Main {
    public static void main(String[] args) throws Exception{
        //Creamos un objeto Scanner
        Scanner reader = new Scanner(System.in);
        //Pedimos la usuario que introduzca un número.
        System.out.println("Escribe un número");
        //Creamos un bloque try/catch que intentará ejecutar el código
        //pero lanzará un error si no se introduce un número
        try{
            //Creamos la variable X y le asignamos el valor que introduzcamos por teclado
            int x = reader.nextInt();
            //Si el número introducido es menor o igual a 0
            if(x<=0){
                //Nos muestra un mensaje de error
                System.out.println("Error");
                //Si no es menor o igual a 0
            } else{
                //Nos muestra el cuadrado y la raíz cuadrada del número introducido
                //Redondeamos el número ya que Math.pow considera ambos números introducidos como double
                //y nos mostraría decimales.
                System.out.println(x+" al cuadrado: "+Math.round(Math.pow(x, 2)));
                //Usamos el método sqrt() de la librería Math para calcular la raíz cuadrada del número introducido.
                System.out.println("Raíz cuadrada de "+x+": "+Math.sqrt(x));
            }
        } catch(Exception e){
            System.out.println("Número introducido incorrecto:\n"+e);
        }
    }
}