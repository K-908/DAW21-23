//importamos la utilidad Scanner para poder introducir datos por teclado.
import java.util.Scanner;
//importamos la utilidad Exception para poder lanzar excepciones
import java.lang.Exception;
public class Main {
    public static void main(String[] args) throws Exception{
        //Creamos un objeto Scanner
        Scanner reader = new Scanner(System.in);
        //Rodeamos el código en un bloque try/catch para asegurar que los números introducidos son corretos.
            try{
                //Pedimos la usuario que indique cuántos niños hay.
                System.out.println("¿Cuántos niños hay en el curso?");
                //Introducimos el valor en una variable
                int nino = reader.nextInt();
                //Pedimos la usuario que indique cuántas niñas hay.
                System.out.println("¿Y cuántas niñas?");
                int nina = reader.nextInt();
                //Creamos una variable con el número total de alumnos.
                int total = nino+nina;
                //Mostramos por pantalla el número total de alumnos
                System.out.println("Total de alumnos: "+total);
                /*
                 * Usamos un printf que nos muestre sólo 2 números decimales.
                 * El porcentaje lo sacamos dividiendo el número de niños/niñas enre el total y multiplicando por 100
                 **/
                System.out.printf("Porcentaje de niños: %.2f%%\n",((double)nino/total)*100);
                System.out.printf("Porcentaje de niñas: %.2f%%\n",((double)nina/total)*100);
            } catch(Exception e){
                System.out.println("Número introducido incorrecto");
        }
    }
}