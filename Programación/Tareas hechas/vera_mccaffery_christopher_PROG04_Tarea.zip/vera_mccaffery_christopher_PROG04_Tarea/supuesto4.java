//importamos la utilidad Scanner para poder introducir datos por teclado.
import java.util.Scanner;
//importamos la utilidad Exception para poder lanzar excepciones
import java.lang.Exception;
public class Main {
    public static void main(String[] args) throws Exception{
        //Creamos un objeto Scanner
        Scanner reader = new Scanner(System.in);
        //Rodeamos el código en un bloque try/catch para asegurar que los números introducidos son corretos.
        try{
            //Pedimos la usuario que introduzca la temperatura
            System.out.println("Introduce la temperatura: ");
            //Creamos una variable que guarde la temperatura introducida
            int temperatura = reader.nextInt();
            //Ahora comprobamos con un if/else qué deporte se debería practicar
            if(temperatura>30){
                System.out.println("Natación");
            } else if(temperatura>15&&temperatura<=30){
                System.out.println("Tenis");
            }else if(temperatura>10&&temperatura<=15){
                System.out.println("Esquí");
            } else{
                System.out.println("Damas");
            }
        } catch(Exception e){
            System.out.println("Número introducido incorrecto: "+e);
        }
    }
}
