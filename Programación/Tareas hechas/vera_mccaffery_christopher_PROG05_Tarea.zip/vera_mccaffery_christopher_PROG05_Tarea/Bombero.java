/*Importamos clases necesarias para el correcto funcionamiento del programa*/
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;
//Creamos la clase Bombero que heredará de la clase Funcionario
public class Bombero extends Funcionario{
    //Establecemos las variables adicionales para Bombero. También usará la que establecimos en Funcionario.
    private Puesto puesto;
    private String parque;
    //Creamos una variable estática que llevará la cuenta de cuántos bomberos hemos creado
    private static int bomberosCreados = 0;
//Constructor vacío. Lo único que hace es aumentar en 1 la variable estática que lleva la cuenta de los bomberos creados.
    public Bombero() {
        bomberosCreados++;
    }
//Constructor que solicita todos los parámetros: tanto los propios de la clase Bombero como los generales de l
    public Bombero(String nombre, String apellidos, int edad, Date fechaIngreso, Puesto puesto, String parque) {
        super(nombre, apellidos, edad, fechaIngreso);
        this.puesto = puesto;
        this.parque = parque;
        bomberosCreados++;
    }
//Devuelve el objeto del atributo Puesto
    public Puesto getPuesto() {
        return puesto;
    }
//Establece el atributo Puesto al objeto Puesto que se le pase como parámetro
    public void setPuesto(Puesto puesto) {
        this.puesto = puesto;
    }
//Devuelve el atributo parque
    public String getParque() {
        return parque;
    }
//Establece el atributo Parque al String que se le pase como parámetro
    public void setParque(String parque) {
        this.parque = parque;
    }
//Variable global que devuelve el número de objetos que se han creado
    public static int getBomberosCreados() {
        return bomberosCreados;
    }
    //Método que calcula la antiguedad del Bombero
    public void calcularAntiguedad(){
        //Creamos una variable que guarda la conversión de la fecha en la que entró en días
        double diasDesdeIngreso = TimeUnit.MILLISECONDS.toDays(this.getFechaIngreso().getTime());
        //Creamos una variable que guarda la conversión de la fecha de hoy en días
        double diasDesdeHoy = TimeUnit.MILLISECONDS.toDays(new Date().getTime());
        //Creamos una variable con los años de diferencia que hay entre la fecha en la que entró y la de hoy
        double aniosPasados = ((diasDesdeHoy - diasDesdeIngreso) / 365);
        //Dependiendo del número de años que hayan pasado, le subimos el sueldo un porcentaje u otro
        if(aniosPasados >= 10){
            this.puesto.setSueldo(this.puesto.getSueldo()*1.1);
        } else if(aniosPasados >= 5 && aniosPasados <10){
            this.puesto.setSueldo(this.puesto.getSueldo()*1.05);
        } else if(aniosPasados >= 1 && aniosPasados<5){
            this.puesto.setSueldo(this.puesto.getSueldo()*1.01);
        }
    }
    //Método que muestra por pantalla la información del Bombero. Sobreescribe el método con el mismo nombre
    //en la clase "Funcionario"
    @Override
    public void getInfo(){
        SimpleDateFormat formatter= new SimpleDateFormat("yyyy-MM-dd");
        System.out.printf("El bombero %s %s, tiene %d años de edad e ingresó en el cuerpo %tF.%nTrabaja en el parque %s y su puesto es %s. Cobra %,.2f€%n", this.getNombre(), this.getApellidos(), this.getEdad(), this.getFechaIngreso(), this.getParque(), this.puesto.getNombrePuesto(), this.puesto.getSueldo());
    }
}
