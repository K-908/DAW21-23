//Importamos las librerías necesarias para que el programa funcione bien
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class BomberoMain {
    public static void main(String[] args) throws ParseException {
        //Creamos un objeto Scanner para poder introducir información por teclado
        Scanner reader = new Scanner(System.in);
        //Empezamos creando un array de objetos Puesto para simplificar el código en main
        Puesto[] puestos = new Puesto[3];
        //Añadimos las categorías a un array para añadirlas a los objetos Puesto
        String categorias[] = new String[]{"Peón", "Cabo", "Especialista"};
        //Creamos un bucle que se repetirá 3 veces para crear 3 objetos puesto
        for (int i = 0; i < 3; i++) {
            //Pedimo al usuario que introduzca el nombre del puesto que se está asignando en el bucle
            System.out.println("Introduce el nombre del puesto " + (i + 1));
            //Creamos el atributo sin inicializarlo
            String puesto;
            //Bucle que se repetirá hasta que introduzcamos un nombre válido
            while(true){
                try{
                    //Se pide al usuario que introduzca el nombre por teclado
                    puesto = reader.nextLine();
                    //No se ha especificado nada con respecto al nombre, así que únicamente comprobará que no es un String vacío
                    if(!puesto.isEmpty()){
                        break;
                        //Si el String está vacío, lanza un mensaje de error
                    } else{
                        System.out.println("El campo no puede estar vacío");
                    }
                } catch(Exception e){
                    System.out.println("Error al introducir datos: "+e);
                }
            }

            //Mismo procedimiento para el nombre del puesto, pero para la descripción
            System.out.println("Introduce la descripción del puesto " + (i + 1));
            String descripcion;
            while(true){
                try{
                    descripcion = reader.nextLine();
                    if(!descripcion.isEmpty()){
                        break;
                    } else{
                        System.out.println("El campo no puede estar vacío");
                    }
                } catch(Exception e){
                    System.out.println("Error al introducir datos: "+e);
                }
            }
            //Cuando tenemos todos los datos necesarios, usamos el constructor del objeto Puesto para crearlo
            puestos[i] = new Puesto(puesto, categorias[i], descripcion);
        }
        //Al igual que con los objetos Puesto, creamos un bucle para crear 3 objetos Bombero
        Bombero[] bomberos = new Bombero[3];
        for (int i = 0; i < 3; i++) {
            System.out.println("Información sobre el bombero " + (i + 1) + ": ");
            System.out.println("Nombre:");
            String nombre;
            //Para las variables "nombre" y "apellidos" sólo comprobamos que no se introduzca un campo vacío
            while(true){
                try{
                    nombre = reader.nextLine();
                    if(!nombre.isEmpty()){
                        break;
                    } else{
                        System.out.println("El campo no puede estar vacío");
                    }
                } catch(Exception e){
                    System.out.println("Error al introducir datos: "+e);
                }
            }

            System.out.println("Apellidos:");
            String apellidos;
            while(true){
                try{
                    apellidos = reader.nextLine();
                    if(!apellidos.isEmpty()){
                        break;
                    } else{
                        System.out.println("El campo no puede estar vacío");
                    }
                } catch(Exception e){
                    System.out.println("Error al introducir datos: "+e);
                }
            }
            //Pero para la edad comprobamos que el rango de edad esté comprendido entre 18 y 100
            System.out.println("Edad:");
            int edad = 0;
            while(true){
                try{
                    edad = Integer.parseInt(reader.nextLine());
                    if(edad >=18 && edad <=100){
                        break;
                    } else{
                        System.out.println("Introduce una edad válida");
                    }
                } catch(NumberFormatException e){
                    System.out.println("Por favor, introduce una edad válida");
                }
            }
            //Pedimos al usuario que introduzca la fecha de ingreso con un formato específico
            System.out.println("Fecha de ingreso (dd-mm-aaaa):");
            //Iniciamos una variable "fecha" que será un String vacío.
            String fecha = "";
            //La librería "SimpleDateFormat" hace que sea más sencillo trabajar con fechas. Creamos el formato que queremos que tenga la fecha
            SimpleDateFormat formatoFecha = new SimpleDateFormat("dd-MM-yyyy");
            //Hacemos que sea estricto con la fecha introducida. Si no, aceptaría cosas como 99-99-9999 y los días y meses que se pasase de los existentes los pasaría al siguiente
            formatoFecha.setLenient(false);
            //Creamos un objeto "Date" vacío
            Date fechaIngreso = null;
            //Bucle para comprobar que la fecha introducida es correcta
            while(true){
                try {
                    //Pedimo al usuario que la escriba
                    fecha = reader.nextLine();
                    //Convertimos el texto introducido en una fecha
                    fechaIngreso = formatoFecha.parse(fecha);
                    //Detenemos el bucle si ha salido bien
                    break;
                    //Si no ha salido bien, lanza un error
                } catch (ParseException e) {
                    System.out.println("Introduce una fecha válida con el formato dd-MM-YYYY");
                }
            }
            //Pedimos al usuario que escriba el parque en el que trabaja y comprobamos que no es un campo vacío, como con nombre y apellidos
            System.out.println("Parque en el que trabaja: ");
            String parque;
            while(true){
                try{
                    parque = reader.nextLine();
                    if(!parque.isEmpty()){
                        break;
                    } else{
                        System.out.println("El campo no puede estar vacío");
                    }
                } catch(Exception e){
                    System.out.println("Error al introducir datos: "+e);
                }
            }
            //Creamos el objeto Bombero con los datos que hemos obtenido
            bomberos[i] = new Bombero(nombre, apellidos, edad, fechaIngreso, puestos[i], parque);
        }
        //Mostramos el número de bomberos creados usando el método global "getBomberosCreados()"
        System.out.println("Número de bomberos creado: "+Bombero.getBomberosCreados());
        //Creamos un objeto Date con la fecha de hoy
        Date hoy = new Date();
        //Para asignar una nueva fecha, usamos el objeto Date con la fecha de hoy y le restamos 1, 5 y 10 años al año
        //Después asignamos esa fecha como nueva variable "fechaIngreso" de cada objeto Bombero
        Date nuevoIngreso = new Date(hoy.getYear()-1, hoy.getMonth(), hoy.getDate());
        bomberos[0].setFechaIngreso(nuevoIngreso);
        nuevoIngreso = new Date(hoy.getYear()-5, hoy.getMonth(), hoy.getDate());
        bomberos[1].setFechaIngreso(nuevoIngreso);
        nuevoIngreso = new Date(hoy.getYear()-10, hoy.getMonth(), hoy.getDate());
        bomberos[2].setFechaIngreso(nuevoIngreso);
        //Usamos el método "calcularAntiguedad" para que actualice el salario y "getInfo" para que muestre la información por pantalla
        bomberos[0].calcularAntiguedad();
        bomberos[0].getInfo();
        bomberos[1].calcularAntiguedad();
        bomberos[1].getInfo();
        bomberos[2].calcularAntiguedad();
        bomberos[2].getInfo();
        //Pedimos al usuario que introduzca información para crear un nuevo puesto.
        System.out.printf("Nuevo puesto de %s %s:%n", bomberos[0].getNombre(), bomberos[0].getApellidos());
        System.out.println("Nombre del puesto: ");
        String nuevoNombre = reader.nextLine();
        System.out.println("Descripción del puesto: ");
        String nuevaDescripcion = reader.nextLine();
        //Creamos un nuevo objeto "Puesto" vacío
        Puesto nuevoPuesto = new Puesto();
        //Usamos los setter de Puesto para añadirle la información
        nuevoPuesto.setNombrePuesto(nuevoNombre);
        nuevoPuesto.setDescripcionPuesto(nuevaDescripcion);
        nuevoPuesto.setCategoria();
        //Asignamos el nuevo objeto Puesto al primer Bombero
        bomberos[0].setPuesto(nuevoPuesto);
        //Recalculamos la antiguedad
        bomberos[0].calcularAntiguedad();
        //Y mostramos la información del bombero por pantalla
        bomberos[0].getInfo();
        //Asignamos al primer bombero el puesto del 2º
        bomberos[0].setPuesto(bomberos[1].getPuesto());
        //Asignamos al segundo bombero el parque del 3º
        bomberos[1].setParque(bomberos[2].getParque());
    }
}