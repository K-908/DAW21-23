//Importamos las librerías necesarias para el correcto funcionamiento del programa.
import java.util.Scanner;

public class Puesto {
    private String nombrePuesto;
    private String categoria;
    private String descripcionPuesto;
    private double sueldo;
    Scanner reader = new Scanner(System.in);
    //Constructor del objeto Puesto que recibe parámetros para todas la variables
    public Puesto(String nombrePuesto, String categoria, String descripcionPuesto) {
        //Comprueba que el atributo "categoría" es una de las 3 opciones aceptables (peón está escrito tanto con acento como sin él)
        //Si forma parte de una de las categorías
        if(categoria.toLowerCase().equals("peon") || categoria.toLowerCase().equals("cabo") ||categoria.toLowerCase().equals("especialista") ||categoria.toLowerCase().equals("peón")){
            //Lo establece como la variable "categoría"
            this.categoria = categoria;
            //Si no
        } else{
            //Lanza un mensaje de error
            throw new IllegalArgumentException("Opción inválida: "+categoria);
        }
    //La variable "salario" depende de la variable "categoria"
        //Este switch asigna un valor a la variable "sueldo" en función del valor de la categoría
        switch (categoria.toLowerCase()) {
            case "peon", "peón" -> this.sueldo = 1500;
            case "cabo" -> this.sueldo = 1800;
            case "especialista" -> this.sueldo = 2000;
        }
        //Asignamos el resto de las variables

        this.nombrePuesto = nombrePuesto;
        this.descripcionPuesto = descripcionPuesto;

    }
    //Constructor vacío
    public Puesto(){

    }
    //Método que nos devuelve un String con el valor de la variable "nombrePuesto"
    public String getNombrePuesto() {
        return nombrePuesto;
    }
    //Método que recibe un String como parámetro y lo asigna a la variable "nombrePuesto"
    public void setNombrePuesto(String nombrePuesto) {
        this.nombrePuesto = nombrePuesto;
    }
    //Método que nos devuelve un String con el valor de la variable "categoria"
    public String getCategoria() {
        return categoria;
    }
    //Método para establecer la categoría del objeto Puesto. A diferencia de otros setter, no recibe parámetros
    public void setCategoria() {
        //En su lugar se le pide al usuario que introduzca el valor de la nueva categoría
        System.out.println("Nueva categoría: ");
        //Bucle que comprueba que el texto introducido es correcto
        while(true){
            try{
                //Primero comprueba que el texto introducido es una de las 3 categorías posibles
                String categoria = reader.nextLine();
                if(categoria.toLowerCase().equals("peon") || categoria.toLowerCase().equals("cabo") ||categoria.toLowerCase().equals("especialista") ||categoria.toLowerCase().equals("peón")){
                    //Si lo es, lo establece como la variable "categoria" del objeto
                    this.categoria = categoria;
                    //Y termina el bucle
                    break;
                    //Si no
                } else{
                    //Nos indica que la categoría es incorrecta y se vuelve a repetir el bucle.
                    System.out.println("Categoría incorrecta");
                }
                //Lanza una excepción
            } catch(IllegalArgumentException e){
                System.out.println("Categoría incorrecta: "+e.getCause());
            }
        //Cada vez que cambia la categoría tiene que cambiar el salario, así qeu lo volvemos a asignar
        }
        switch (categoria.toLowerCase()) {
            case "peon", "peón" -> this.sueldo = 1500;
            case "cabo" -> this.sueldo = 1800;
            case "especialista" -> this.sueldo = 2000;
        }
    }
    //Método que nos devuelve un String con el valor de la variable "descripcionPuesto"
    public String getDescripcionPuesto() {
        return descripcionPuesto;
    }

    public void setDescripcionPuesto(String descripcionPuesto) {
        this.descripcionPuesto = descripcionPuesto;
    }
    //Método que nos devuelve un double con el valor de la variable "sueldo"
    public double getSueldo() {
        return this.sueldo;
    }
    //Método qeu recibe un "double" como parámetro y lo asigna a la variable "sueldo"
    public void setSueldo(double sueldo) {
        this.sueldo = sueldo;
    }
}
