/*Importamos clases necesarias para el correcto funcionamiento del programa*/
import java.util.Date;
import java.util.Scanner;

public class Funcionario {
    private String nombre;
    private String apellidos;
    private int edad;
    private Date fechaIngreso;
    Scanner reader = new Scanner(System.in);
    //Constructor de la clase "Funcionario" sin parámetros
    public Funcionario(){

    }
    //Constructor de la clase "Funcionario" que recibe todos los atributos como parámetros
    public Funcionario(String nombre, String apellidos, int edad, Date fechaIngreso){
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.edad = edad;
        this.fechaIngreso = fechaIngreso;
    }
    //Método que devuelve un String con el atributo "nombre"
    public String getNombre() {
        return nombre;
    }
    //Método que devuelve un String con el atributo "apellidos"

    public String getApellidos() {
        return apellidos;
    }
    //Método que devuelve un int con el atributo "edad"
    public int getEdad() {
        return edad;
    }
    //Método que devuelve un objeto Date con el atributo "fechaIngreso"

    public Date getFechaIngreso() {
        return fechaIngreso;
    }
    //Método que recibe un objeto String como parámetro y lo establece como la variable "nombre"

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    //Método que recibe un objeto String como parámetro y lo establece como la variable "apellidos"
    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }
    //Método que recibe un parámetro int como parámetro y lo establece como la variable "edad"
    public void setEdad(int edad) {
        this.edad = edad;
    }
    //Método que recibe un objeto Date como parámetro y lo establece como la variable "fechaIngreso"
    public void setFechaIngreso(Date fechaIngreso) {
        this.fechaIngreso = fechaIngreso;
    }
    //Método que muestra por pantalla la información  del objeto que invoca este método
    public void getInfo(){
        System.out.printf("El funcionario %s %s, tiene %n años de edad e ingresó en el cuerpo %t", this.getNombre(), this.getApellidos(), this.getEdad(), this.getFechaIngreso());
    }


}
