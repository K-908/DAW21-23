/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package prog11;

import java.sql.*;

/**
 *
 * @author Gogloglo
 */
public class Prog11 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws ClassNotFoundException, SQLException {
        /*try{
            Class.forName("com.mysql.jdbc.Driver");
            String connectionURL = "jdbc:mysql://localhost/world?"+"user=root&password=13098";
            Connection con = DriverManager.getConnection(connectionURL);
            System.out.println("Ha funcionado");
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM CITY");
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnCount = rsmd.getColumnCount();
            String output = "";
            for(int i=1;i<=columnCount;i++){
                output+=(rsmd.getColumnLabel(i)+"\t\t\t\t");
            }
            output+=("\n");
            while(rs.next()){
                for(int i=1;i<=columnCount;i++){
                    if (rsmd.getColumnType(i) == Types.INTEGER) {
                        output+=(rs.getInt(i) + "\t\t\t\t");
                    }else{
                        output+=(rs.getString(i)+"\t\t\t\t");
                    }
                }
               output+=("\n");
            }
            System.out.println(output);
        }catch(SQLException e){
            System.out.println("SQL Exception: "+e.toString());
            
        }catch(ClassNotFoundException cnf){
            System.out.println("Class not found: "+cnf.toString());

        }*/
                Pagina pagina = new Pagina();
        pagina.show();
        
        
    }
    
    
    
    
}
