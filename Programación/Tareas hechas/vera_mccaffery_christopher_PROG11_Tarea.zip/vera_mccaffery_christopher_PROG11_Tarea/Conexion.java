/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prog11;

import java.sql.*;

/**
 *
 * @author Gogloglo
 */
public class Conexion {
    Connection con = null;
    public Conexion(){
        
    }
    
    public Connection conectar(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            String connectionURL = "jdbc:mysql://localhost/world?"+"user=root&password=13098";
            this.con = DriverManager.getConnection(connectionURL);
        }catch(SQLException e){
            System.out.println("SQL Exception: "+e.toString());
            
        }catch(ClassNotFoundException cnf){
            System.out.println("Class not found: "+cnf.toString());
        }
        return this.con;
    }
    
    public void crearTabla(String query) throws SQLException{
        this.con = this.conectar();
        Statement stmt = this.con.createStatement();
        stmt.executeUpdate(query);
        this.con.close();
    }
    
    public String mostrarTabla(String query) throws SQLException{
        this.con = this.conectar();
        Statement stmt = this.con.createStatement();
        ResultSet rs = stmt.executeQuery(query);
        ResultSetMetaData rsmd = rs.getMetaData();
        int columnCount = rsmd.getColumnCount();
        String output = "";
        for(int i=1;i<=columnCount;i++){
            output+=(rsmd.getColumnLabel(i)+"\t\t\t");
        }
        output+="\n";
        while(rs.next()){
                for(int i=1;i<=columnCount;i++){
                    if (rsmd.getColumnType(i) == Types.INTEGER) {
                        output+=(rs.getInt(i) + "\t\t\t");
                    }else{
                        output+=(rs.getString(i)+"\t\t\t");
                    }
                }
                output+=("\n");
            }
        this.con.close();
        return output;
        }
    
    public void insertarDatos(String query) throws SQLException{
        this.con = this.conectar();
        Statement stmt = this.con.createStatement();
        stmt.executeUpdate(query);
        this.con.close();
    }
}
