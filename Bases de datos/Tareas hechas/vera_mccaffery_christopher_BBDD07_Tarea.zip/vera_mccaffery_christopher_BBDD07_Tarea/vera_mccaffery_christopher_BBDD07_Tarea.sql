--1.1.	Crea el tipo de objetos "MiembroEscolar" con los siguientes atributos:
CREATE OR REPLACE TYPE MiembroEscolar AS OBJECT(
    codigo INTEGER,
    dni VARCHAR2(10),
    nombre VARCHAR2(30),
    apellidos VARCHAR2(30),
    sexo VARCHAR2(1),
    fecha_nac DATE
    ) NOT FINAL;
/ 


--1.2. Crea, como tipo heredado de "MiembroEscolar", el tipo de objeto "Profesor" con los siguientes atributos:
CREATE TYPE Profesor UNDER MiembroEscolar(
    especialidad VARCHAR2(20),
    antiguedad INTEGER
);	
/

--1.3. Crea el tipo de objeto "Cursos" con los siguientes atributos:

CREATE TYPE Cursos AS OBJECT(
    codigo INTEGER,
    nombre VARCHAR2(20),
    refProfe REF Profesor,
    max_Alumn INTEGER,
    fecha_Inic DATE,
    fecha_Fin DATE,
    num_Horas INTEGER
);

--1.4. Crea, como tipo heredado de "MiembroEscolar", el tipo de objeto "Alumno" con los siguientes atributos:

CREATE TYPE Alumno UNDER MiembroEscolar(
    cursoAlumno Cursos
);

--2. Crea un método constructor para el tipo de objetos "Profesor", en el que se indiquen como parámetros el código, nombre, primer apellido, segundo apellido y especialidad. Este método debe asignar al atributo "apellidos" los datos de primer apellido y segundo apellido que se han pasado como parámetros, uniéndolos con un espacio entre ellos.
ALTER TYPE Profesor ADD CONSTRUCTOR FUNCTION Profesor(
    codigo INTEGER, 
    nombre VARCHAR2,
    primerApellido VARCHAR2, 
    segundoApellido VARCHAR2, 
    especialidad VARCHAR2)
RETURN SELF AS RESULT CASCADE;
/
	

CREATE OR REPLACE TYPE BODY Profesor AS 
CONSTRUCTOR FUNCTION Profesor(
    codigo INTEGER, 
    nombre VARCHAR2,
    primerApellido VARCHAR2, 
    segundoApellido VARCHAR2, 
    especialidad VARCHAR2)
RETURN SELF AS RESULT IS
BEGIN 
  SELF.codigo := codigo;
  SELF.nombre := nombre;
  SELF.apellidos := primerApellido||' '||segundoApellido;
  SELF.especialidad := especialidad;
  RETURN;
END;
END;
/

--3. Crea un método "getNombreCompleto" para el tipo de objetos "Profesor" que permita obtener su nombre completo con el formato "apellidos nombre".
ALTER TYPE Profesor ADD MEMBER FUNCTION getNombreCompleto RETURN VARCHAR2 CASCADE;

CREATE OR REPLACE TYPE BODY Profesor AS
CONSTRUCTOR FUNCTION Profesor(
    codigo INTEGER, 
    nombre VARCHAR2,
    primerApellido VARCHAR2, 
    segundoApellido VARCHAR2, 
    especialidad VARCHAR2)
RETURN SELF AS RESULT IS
BEGIN 
  SELF.codigo := codigo;
  SELF.nombre := nombre;
  SELF.apellidos := primerApellido||' '||segundoApellido;
  SELF.especialidad := especialidad;
  RETURN;
END;
 
MEMBER FUNCTION getNombreCompleto RETURN VARCHAR2  
 IS
    BEGIN
        RETURN SELF.apellidos || ' ' || SELF.nombre;
    END getNombreCompleto;
 END;
/

--4. Crea un tabla "Profesorado" de objetos "Profesor". Inserta en dicha tabla dos objetos "Profesor". El primero de ellos con los datos:

CREATE TABLE Profesorado OF Profesor;
 DECLARE 
    prof1 Profesor;
    prof2 Profesor;
BEGIN
    prof1 := new Profesor(2,'MARIA LUISA', 'FABRE', 'BERDUN', 'TECNOLOGIA');
    --En un apartado anterior sustituimos el constructor por defecto, uso el que creé y añado los atributos que faltan
        prof1.sexo := 'F';
        prof1.fecha_nac := TO_DATE('31/03/1975', 'dd/mm/yyyy');
        prof1.antiguedad := 4;
        
    prof2 := new Profesor(3, 'Javier', 'Jimenez', 'Hernando', 'Lengua');
INSERT INTO Profesorado VALUES (prof1);
INSERT INTO Profesorado VALUES (prof2);
END;

--5. Crea una colección VARRAY llamada "ListaCursos" en la que se puedan almacenar hasta 10 objetos "Cursos". Guarda en una instancia "listaCursos1" de dicha lista, los dos cursos siguientes:


CREATE OR REPLACE TYPE ListaCursos IS VARRAY (10) OF cursos;
/

DECLARE
    listaCursos1 ListaCursos;
    prof1 REF Profesor;
    prof2 REF Profesor;
    curso1 Cursos;
    curso2 Cursos;
BEGIN
    SELECT REF(p) INTO prof1 FROM Profesorado p WHERE p.codigo = 3;
    SELECT REF(p) INTO prof2 FROM Profesorado p WHERE p.dni = '51083099F'; --No hemos introducido ningún dato en la tabla con este DNI, ambos profesores tienen como DNI "Null". Añado la información manualmente antes de ejecutarlo.
    curso1 := new Cursos(1, 'Curso 1', prof1, 20, TO_DATE('01/06/2011', 'dd/mm/yyyy'), TO_DATE('30/06/2011', 'dd/mm/yyyy'), 30);
    curso2 := new Cursos(2, 'Curso 2', prof2, 20, TO_DATE('1/06/2011', 'dd/mm/yyyy'),TO_DATE('30/06/2011', 'dd/mm/yyyy'), 30);
    listaCursos1 := listaCursos(curso1, curso2);
END;
/

--6. Crea una tabla "Alumnado" de objetos "Alumno". Inserta en dicha tabla las siguientes filas:
CREATE TABLE Alumnado OF Alumno;

DECLARE
    listaCursos1 ListaCursos;
    curso1 Cursos;
    curso2 Cursos;
    
    prof1 REF Profesor;
    prof2 REF Profesor;
    
    alumno1 Alumno;
    alumno2 Alumno;
BEGIN
    SELECT REF(p) INTO prof1 FROM Profesorado p WHERE p.codigo = 3;
    SELECT REF(p) INTO prof2 FROM Profesorado p WHERE p.dni = '51083099F';
    curso1 := new Cursos(1, 'Curso 1', prof1, 20, TO_DATE('01/06/2011', 'dd/mm/yyyy'), TO_DATE('30/06/2011', 'dd/mm/yyyy'), 30);
    curso2 := new Cursos(2, 'Curso 2', prof2, 20, TO_DATE('1/06/2011', 'dd/mm/yyyy'),TO_DATE('30/06/2011', 'dd/mm/yyyy'), 30);
    listaCursos1 := listaCursos(curso1, curso2);
    
    alumno1 := new Alumno(100, '76401092Z', 'MANUEL', 'SUAREZ IBAÑEZ', 'M', TO_DATE('30/6/1990', 'dd/mm/yyyy'), curso1);
    alumno2 := new Alumno(102, '6915588V', 'MILAGROSA','DIAZ PEREZ','F',TO_DATE('28/10/1984','dd/mm/yyyy'),listacursos1(2));
    
    INSERT INTO alumnado VALUES (alumno1);
    INSERT INTO alumnado VALUES (alumno2);
    
END;
/

--7. Obtener, de la tabla "Alumnado", el alumno que tiene el código 100, asignándoselo a una variable "unAlumno". Modifica el código del alumno guardado en esa variable "unAlumno" asignando el valor 101, y su curso debe ser el segundo que se había creado anteriormente. Inserta ese alumno en la tabla "Alumnado".

DECLARE
unAlumno Alumno;
unCurso Cursos;
begin
    SELECT VALUE(a) INTO unAlumno FROM Alumnado a WHERE a.codigo = 100;
    SELECT a.cursoAlumno INTO unCurso FROM Alumnado a WHERE a.cursoAlumno.codigo = 2;
    
    unAlumno.codigo := 101;
    
    unAlumno.cursoAlumno := unCurso;
end;
