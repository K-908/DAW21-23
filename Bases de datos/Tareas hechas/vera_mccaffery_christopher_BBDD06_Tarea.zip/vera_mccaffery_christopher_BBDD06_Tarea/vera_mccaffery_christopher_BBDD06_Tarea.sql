/*
***************************************************
*****************EJERCICIO 1***********************
***************************************************
*/

CREATE OR REPLACE FUNCTION CALCULAR_PEDIDO(cod_pedido e_pedidos.codigopedido%type)
RETURN NUMBER
AS
    CURSOR productos_pedido IS
    SELECT p.precioventa, d.unidadespedidas
    FROM e_detallepedidos d, e_productos p
    WHERE p.codigoproducto = d.codigoproducto
    AND d.codigopedido = cod_pedido;

v_total number(8) := 0;
BEGIN
    FOR fila IN productos_pedido LOOP
        IF fila.unidadespedidas >=0 AND fila.unidadespedidas <=0 THEN
            v_total := v_total+(fila.precioventa*fila.unidadespedidas);
        
        elsif fila.unidadespedidas >=6 AND fila.unidadespedidas <=10 THEN
            v_total := v_total+((fila.precioventa*fila.unidadespedidas)*0.95);
        
        elsif fila.unidadespedidas >=11 AND fila.unidadespedidas <=15 THEN
            v_total := v_total+((fila.precioventa*fila.unidadespedidas)*0.93);
        
        else 
            v_total := v_total+((fila.precioventa*fila.unidadespedidas)*0.9);
        END IF;

    END LOOP;
    
    return v_total;

END;
/

/*
***************************************************
*****************EJERCICIO 2***********************
***************************************************
*/
CREATE OR REPLACE PROCEDURE CALCULAR_CLIENTE(cod_cliente e_clientes.codigocliente%type, c_year NUMBER, total_pagado OUT NUMBER, total_no_pagado OUT NUMBER)
AS

    numPedidos number(8);
    existeCliente e_clientes.codigocliente%type;
    pedidosInsuficientes exception;
    
    cursor pedidos_pagados is
        SELECT codigopedido
        FROM e_pedidos p
        WHERE cod_cliente = p.codigocliente
        AND pedidopagado = 'S'
        AND fechaentrega like ('%' ||c_year);
        
    cursor pedidos_no_pagados is
        SELECT codigopedido
        FROM e_pedidos p
        WHERE cod_cliente = p.codigocliente
        AND pedidopagado = 'N'
        AND fechaentrega like ('%' ||c_year);

BEGIN

total_pagado := 0;
total_no_pagado := 0;

    SELECT codigocliente INTO existeCliente
    FROM e_clientes c
    WHERE cod_cliente = c.codigocliente;
    
    SELECT COUNT(*) INTO numPedidos
    FROM e_pedidos p
    WHERE cod_cliente = p.codigocliente
    AND fechaentrega like ('%' ||c_year);
    
    IF numPedidos < 2 THEN
        RAISE pedidosInsuficientes;
    END IF;
    
    FOR fila IN pedidos_pagados LOOP
        total_pagado := total_pagado+ CALCULAR_PEDIDO(fila.codigopedido);
    END LOOP;
    
    FOR fila IN pedidos_no_pagados LOOP
        total_no_pagado := total_no_pagado+ CALCULAR_PEDIDO(fila.codigopedido);
    END LOOP;
    
EXCEPTION
    WHEN no_data_found THEN
        DBMS_OUTPUT.PUT_LINE('Cliente no encontrado');
        total_pagado := -1;
        total_no_pagado := -1;
        
    WHEN pedidosInsuficientes THEN
        DBMS_OUTPUT.PUT_LINE('El cliente tiene menos de 2 pedidos');
        total_pagado := -1;
        total_no_pagado := -1;
END;


/*
***************************************************
*****************EJERCICIO 3.1*********************
***************************************************
*/
CREATE OR REPLACE TRIGGER DISP_PEDIDOS
BEFORE INSERT OR UPDATE ON E_PEDIDOS FOR EACH ROW

BEGIN


    IF :new.fechapedido > :new.fechaesperada THEN
        raise_application_error(-20001, 'La fecha de pedido no puede ser posterior a la fecha esperada');
    END IF;    
    
    IF :new.fechapedido > :new.fechaentrega THEN
        raise_application_error(-20002, 'La fecha de pedido no puede ser posterior a la fecha de entrega');
    END IF;
    
    IF :new.estadoenvio NOT IN('P', 'D', 'E') THEN
        raise_application_error(-20003, 'El estado del envío sólo puede ser P, D ó E.');
    END IF;
    
    IF :new.pedidopagado NOT IN('S', 'N') THEN
        raise_application_error(-20004, 'El estado del pago sólo puede ser S ó N.');
    END IF;
    
END;
 /

/*
***************************************************
*****************EJERCICIO 3.2*********************
***************************************************
*/
 
CREATE OR REPLACE TRIGGER DISP_DETALLEPEDIDOS
BEFORE INSERT OR UPDATE ON e_detallepedidos FOR EACH ROW
DECLARE
    stock_producto e_productos.cantidadenstock%type;
    nombre_producto e_productos.nombreproducto%type;

BEGIN
    SELECT cantidadenstock INTO stock_producto
    FROM e_productos 
    WHERE codigoproducto = :new.codigoproducto;
    
    IF stock_producto < :new.unidadespedidas then
        SELECT nombreproducto INTO nombre_producto
        FROM e_productos 
        WHERE codigoproducto = :new.codigoproducto;
        
        RAISE_APPLICATION_ERROR(-20001, 'No hay suficiente stock de '||nombre_producto);
    END IF;
    
END;
 /