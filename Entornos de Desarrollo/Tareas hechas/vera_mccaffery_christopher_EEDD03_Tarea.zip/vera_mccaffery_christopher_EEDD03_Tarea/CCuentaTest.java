import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CCuentaTest {	
	@Test
	public void testIngresar() {
		CCuenta cuenta = new CCuenta();
		cuenta.ingresar(200);
		assertEquals(200, cuenta.dSaldo);
		cuenta.ingresar(-1);
		assertEquals(200, cuenta.dSaldo);
		cuenta.ingresar(20);
		assertEquals(220, cuenta.dSaldo);
	}
	
	@Test
	public void testRetirar() {
		CCuenta cuenta = new CCuenta();
		cuenta.ingresar(100);
		assertEquals(100, cuenta.dSaldo);
		cuenta.retirar(10);
		assertEquals(90, cuenta.dSaldo);
		cuenta.retirar(0);
		assertEquals(90, cuenta.dSaldo);
		cuenta.retirar(-5);
		assertEquals(90, cuenta.dSaldo);
		cuenta.retirar(80);
		assertEquals(10, cuenta.dSaldo);
		cuenta.retirar(50);
		assertEquals(10, cuenta.dSaldo);
	}
}