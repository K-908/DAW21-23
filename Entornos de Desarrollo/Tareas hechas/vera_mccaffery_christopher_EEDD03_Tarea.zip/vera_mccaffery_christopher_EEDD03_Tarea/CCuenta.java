
public class CCuenta {

	
	public static void main(String[] args) {
        CCuenta cuenta = new CCuenta();
        //ingresamos 100. Debería funcionar
        cuenta.ingresar(100);
        System.out.println("Saldo: "+cuenta.dSaldo);
        //ingresamos 20. Debería funcionar
        cuenta.ingresar(20);
        System.out.println("Saldo: "+cuenta.dSaldo);
        //ingresamos 0. Debería funcionar
        cuenta.ingresar(0);
        System.out.println("Saldo: "+cuenta.dSaldo);
        //ingresamos -1. No debería funcionar
        cuenta.ingresar(-1);
        System.out.println("Saldo: "+cuenta.dSaldo);
        //retiramos 0. Debería funcionar.
        cuenta.retirar(0);
        System.out.println("Saldo: "+cuenta.dSaldo);
        //retiramos -1. No debería funcionar.
        cuenta.retirar(-1);
        System.out.println("Saldo: "+cuenta.dSaldo);
        //retiramos 90. Debería funcionar
        cuenta.retirar(90);
        System.out.println("Saldo: "+cuenta.dSaldo);
        //retiramos 500. No debería funcionar
        cuenta.retirar(500);
        System.out.println("Saldo: "+cuenta.dSaldo);
}

	
public double dSaldo;

	public int ingresar(double cantidad){
    int iCodErr;
     if (cantidad < 0){
    	 System.out.println("No se puede ingresar una cantidad negativa");
         iCodErr = 1;
     } else{
         // Depuracion. Punto de parada. Solo en el 3 ingreso
         dSaldo = dSaldo + cantidad;
         iCodErr = 0;
         }
     	// Depuracion. Punto de parada cuando la cantidad  es menor de 0
     	return iCodErr;
	 }



public void retirar (double cantidad)
{
    if (cantidad <= 0)
    {
        System.out.println("No se puede retirar una cantidad negativa");
    }
    else if (dSaldo < cantidad)
    {
        System.out.println("No se hay suficiente saldo");
    }
    else
    {
    	dSaldo-=cantidad;
    }
}

}
