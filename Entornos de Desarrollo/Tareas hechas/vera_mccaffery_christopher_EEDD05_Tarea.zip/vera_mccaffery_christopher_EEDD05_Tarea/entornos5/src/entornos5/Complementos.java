
import entornos5.Articulos;

public class Complementos extends Articulos {

	private int talla;

	public int getTalla() {
		return this.talla;
	}

	/**
	 * 
	 * @param talla
	 */
	public void setTalla(int talla) {
		this.talla = talla;
	}

	public Complementos() {
		// TODO - implement Complementos.Complementos
		throw new UnsupportedOperationException();
	}

}