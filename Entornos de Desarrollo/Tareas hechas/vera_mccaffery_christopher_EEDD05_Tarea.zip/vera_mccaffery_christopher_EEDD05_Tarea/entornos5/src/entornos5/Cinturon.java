public class Cinturon extends Complementos {

	public Cinturon() {
		// TODO - implement Cinturon.Cinturon
		throw new UnsupportedOperationException();
	}

}