public class AreaInfluencia {
}