public class Proveedor extends Empresa {

	public Proveedor() {
		// TODO - implement Proveedor.Proveedor
		throw new UnsupportedOperationException();
	}

}