public class Guantes extends Complementos {

	public Guantes() {
		// TODO - implement Guantes.Guantes
		throw new UnsupportedOperationException();
	}

}