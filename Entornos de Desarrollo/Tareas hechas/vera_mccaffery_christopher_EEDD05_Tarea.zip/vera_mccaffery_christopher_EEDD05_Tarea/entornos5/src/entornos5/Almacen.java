public class Almacen {

	private Paquete paquete;

	public Almacen() {
		// TODO - implement Almacen.Almacen
		throw new UnsupportedOperationException();
	}

}