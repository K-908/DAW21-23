public class Class {
}