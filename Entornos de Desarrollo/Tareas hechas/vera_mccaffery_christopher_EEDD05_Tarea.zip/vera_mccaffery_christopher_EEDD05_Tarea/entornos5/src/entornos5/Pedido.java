
import java.util.Date;

public class Pedido {

	private Date fecha;
	private double precioTotal;
	private Socio socio;
	private String tarjetaBancaria;
	private CarritoCompra carritoCompra;

	public Date getFecha() {
		return this.fecha;
	}

	/**
	 * 
	 * @param fecha
	 */
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public double getPrecioTotal() {
		return this.precioTotal;
	}

	/**
	 * 
	 * @param precioTotal
	 */
	public void setPrecioTotal(double precioTotal) {
		this.precioTotal = precioTotal;
	}

	public Socio getSocio() {
		return this.socio;
	}

	/**
	 * 
	 * @param socio
	 */
	public void setSocio(Socio socio) {
		this.socio = socio;
	}

	public String getTarjetaBancaria() {
		return this.tarjetaBancaria;
	}

	/**
	 * 
	 * @param tarjetaBancaria
	 */
	public void setTarjetaBancaria(String tarjetaBancaria) {
		this.tarjetaBancaria = tarjetaBancaria;
	}

	public CarritoCompra getCarritoCompra() {
		return this.carritoCompra;
	}

	/**
	 * 
	 * @param carritoCompra
	 */
	public void setCarritoCompra(CarritoCompra carritoCompra) {
		this.carritoCompra = carritoCompra;
	}

}