public class EmpAlmacen {

	private Tienda tienda;

	public EmpAlmacen() {
		// TODO - implement EmpAlmacen.EmpAlmacen
		throw new UnsupportedOperationException();
	}

}