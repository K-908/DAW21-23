public class EmpresaTransporte extends Empresa {
}