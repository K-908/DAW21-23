public class Paquete {

	private Socio socio;
	private Pedido pedido;

	public Socio getSocio() {
		return this.socio;
	}

	/**
	 * 
	 * @param socio
	 */
	public void setSocio(Socio socio) {
		this.socio = socio;
	}

	public Pedido getPedido() {
		return this.pedido;
	}

	/**
	 * 
	 * @param pedido
	 */
	public void setPedido(Pedido pedido) {
		this.pedido = pedido;
	}

}