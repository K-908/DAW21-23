public class Administrador {

	private Tienda tienda;

}