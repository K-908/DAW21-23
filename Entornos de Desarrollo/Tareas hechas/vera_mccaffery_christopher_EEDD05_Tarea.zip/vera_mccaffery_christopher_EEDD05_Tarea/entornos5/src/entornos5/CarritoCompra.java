public class CarritoCompra {

	private Socio socio;

	public Socio getSocio() {
		return this.socio;
	}

	/**
	 * 
	 * @param socio
	 */
	public void setSocio(Socio socio) {
		this.socio = socio;
	}

	public CarritoCompra() {
		// TODO - implement CarritoCompra.CarritoCompra
		throw new UnsupportedOperationException();
	}

}