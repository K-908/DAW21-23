public class Firma extends Empresa {

	public Firma() {
		// TODO - implement Firma.Firma
		throw new UnsupportedOperationException();
	}

}