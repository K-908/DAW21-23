public class Tienda {

	public Tienda() {
		// TODO - implement Tienda.Tienda
		throw new UnsupportedOperationException();
	}

}