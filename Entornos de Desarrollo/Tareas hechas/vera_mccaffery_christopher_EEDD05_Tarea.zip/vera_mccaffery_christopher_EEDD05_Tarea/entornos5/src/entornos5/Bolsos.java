
import entornos5.Articulos;

public class Bolsos extends Articulos {

	private String tipo;

	public String getTipo() {
		return this.tipo;
	}

	/**
	 * 
	 * @param tipo
	 */
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public Bolsos() {
		// TODO - implement Bolsos.Bolsos
		throw new UnsupportedOperationException();
	}

}