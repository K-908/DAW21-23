public class Ruta {

	private AreaInfluencia areaInfluencia;
	private int diasReparto;

	public AreaInfluencia getAreaInfluencia() {
		return this.areaInfluencia;
	}

	/**
	 * 
	 * @param areaInfluencia
	 */
	public void setAreaInfluencia(AreaInfluencia areaInfluencia) {
		this.areaInfluencia = areaInfluencia;
	}

	public int getDiasReparto() {
		return this.diasReparto;
	}

	/**
	 * 
	 * @param diasReparto
	 */
	public void setDiasReparto(int diasReparto) {
		this.diasReparto = diasReparto;
	}

}