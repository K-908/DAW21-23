package entornos5;

public class Articulos {

	private String nombre;
	private String descripcion;
	private String material;
	private String color;
	private double precio;
	private int sotck;

	public String getNombre() {
		return this.nombre;
	}

	/**
	 * 
	 * @param nombre
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDescripcion() {
		return this.descripcion;
	}

	/**
	 * 
	 * @param descripcion
	 */
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getMaterial() {
		return this.material;
	}

	/**
	 * 
	 * @param material
	 */
	public void setMaterial(String material) {
		this.material = material;
	}

	public String getColor() {
		return this.color;
	}

	/**
	 * 
	 * @param color
	 */
	public void setColor(String color) {
		this.color = color;
	}

	public double getPrecio() {
		return this.precio;
	}

	/**
	 * 
	 * @param precio
	 */
	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public int getSotck() {
		return this.sotck;
	}

	/**
	 * 
	 * @param sotck
	 */
	public void setSotck(int sotck) {
		this.sotck = sotck;
	}

	public Articulos() {
		// TODO - implement Articulos.Articulos
		throw new UnsupportedOperationException();
	}

}