
import entornos5.Articulos;

public class Zapatos extends Articulos {

	private int numero;
	private String tipo;

	public int getNumero() {
		return this.numero;
	}

	/**
	 * 
	 * @param numero
	 */
	public void setNumero(int numero) {
		this.numero = numero;
	}

	public String getTipo() {
		return this.tipo;
	}

	/**
	 * 
	 * @param tipo
	 */
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public Zapatos() {
		// TODO - implement Zapatos.Zapatos
		throw new UnsupportedOperationException();
	}

}