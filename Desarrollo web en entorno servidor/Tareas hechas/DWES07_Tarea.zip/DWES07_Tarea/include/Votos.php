<?php
//Clase Votos, que será la encargada de interactuar con la tabla "votos" de la base de datos.
require_once "Conexion.php";
//Hace uso de la clase Conexion
class Votos extends Conexion{
    private $id;
    private $cantidad;
    private $idPr;
    private $idUs;

//Usa el constructor del elemento padre
    public function __construct(){
        parent::__construct();
    }
//Función que nos devuelve todos los elementos de la tabla
    public function getVotos(){
        $consulta = "SELECT * FROM votos ORDER BY id";
        $stmt = self::$conexion->prepare($consulta);
        try{
            $stmt->execute();
        }catch(\PDOException $e){
            die("Error al obtener votos: ".$e->getMessage());
        }
        return $stmt->fetchAll(PDO::FETCH_OBJ);
    }
//Función para contar el número de votos de un producto
    public function cuantosVotos($prod){
        //Creamos la variable que devolverá la función
        $total=0;
        //Selecciona los productos con la ID especificada
        $consulta = "SELECT * FROM votos WHERE idPr=$prod";
        $stmt = self::$conexion->prepare($consulta);
        try{
            $stmt->execute();
            //Cuenta el número de elementos devueltos, es decir, el número de votos
            //y lo suma a la variable que nos devolverá la función
            $total+=$stmt->rowCount();
        }catch(\PDOException $e){
            die("Error al obtener el número de votos: ".$e->getMessage());
        }
        //Nos devuelve el valor de la primera variable. Si ha habido votos, el número de votos, si no, 0
        return $total;
        }
        //Función que nos devuelve la puntuación que tiene un producto
        public function puntuacion($prod){
            //Creamos una variable con el número de votos que ha recibido el producto
            $cantidad=self::cuantosVotos($prod);
            //Variable que tendrá la suma de las puntuaciones del producto
            $total =0;
            //Mensaje que devolverá esta función
            $mensaje="";
            //Si ha habido algún voto, ejecutamos el siguiente código
            if($cantidad>0){
                $consulta = "SELECT cantidad FROM votos WHERE idPr=$prod";
                $stmt = self::$conexion->prepare($consulta);
                try{
                    $stmt->execute();
                }catch(\PDOException $e){
                    die("Error al obtener la puntuación: ".$e->getMessage());
                }
                //Bucle que recorrerá todos los votos que ha recibido el producto y añadirá sus
                //puntuaciones a la variable $total
                while($item=$stmt->fetch(PDO::FETCH_OBJ)){
                    $total+=$item->cantidad;
                }
                //La valoración final será la media de las puntuaciones, es decir, la suma del total de las puntuaciones
                //dividido por el número de puntuaciones. Redondeamos a 2 decimales.
                $valoracion = round($total/$cantidad, 2);
                //Añadimos al mensaje el texto que aparecerá en pantalla
                $mensaje.="Puntuación: ".$valoracion." con ".$cantidad." valoraciones<br>";
                //Añadimos las estrellas al mensaje
                $mensaje.= $this->estrellas($valoracion);
                return $mensaje;
                //Si el producto no ha tenido valoraciones, no calculamos nada y lo decimos en el mensaje
            } else{
                $mensaje.="Este producto no tiene valoraciones";
            } 
            return $mensaje;
        }
        //Función para comprobar que un usuario no está votando dos veces al mismo artículo
        public function votoUnico($idPr, $idUs){
            //Buscamos en la base de datos si hay alguna votación con la misma ID de producto y de usuario
            $consulta = "SELECT * FROM votos WHERE idPr='$idPr' AND idUs='$idUs'";
        $stmt = self::$conexion->prepare($consulta);
        try{
            $stmt->execute();
            $stmt->fetchAll(PDO::FETCH_ASSOC);
        }catch(\PDOException $e){
            die("Error al obtener votos: ".$e->getMessage());
        }
        //Si no hay ninguna votación con esas características, devuelve true
        if($stmt->rowCount()==0){
            return true;
            //Si un usuario ya tiene una votación registrada para esa id de producto, devuelve false
        } else{
            return false;
        }
        }
        //Función que dibuja las estrellas que irán junto a la puntuación del producto
        public function estrellas($num){
            //String que devolverá esta función. Empieza vacío.
            $nota ="";
            //Eliminamos los decimales del número introducido para obtener el número entero
            $entero = floor($num);
            //Restamos el número entero al número introducido para obtener la parte decimal
            $decimal = $num-$entero;
            //Bucle que se recorrerá el número de veces del número entero
            for($i=0;$i<$entero;$i++){
                //Cada vez que recorre el bucle añade una estrella al mensaje
                $nota.="<i class=\"fa fa-star\" aria-hidden=\"true\"></i>";
            }
            //Una vez termina, si la parte decimal es mayor o igual a 0.5, añadimos media estrella
            if($decimal >= 0.5){
                $nota.="<i class=\"fa fa-star-half\" aria-hidden=\"true\"></i>";
            }
            //Devolvemos el String con las estrellas
            return $nota;
        }
        //Función para añadir votos a la base de datos
        public function votar($cant, $prod, $usu){
            $consulta = "INSERT INTO votos
            (cantidad, idPr, idUs)
            VALUES ('$cant', '$prod', '$usu')";
            $stmt = self::$conexion->prepare($consulta);
            try{
                $stmt->execute();
            }catch(\PDOException $e){
                die("Error al votar: ".$e->getMessage());
            }
        }
    }