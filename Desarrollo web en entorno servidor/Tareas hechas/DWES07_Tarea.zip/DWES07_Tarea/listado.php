<?php
session_start();
if(!isset($_SESSION['usu'])){
    header('Location:login.php');
    die();
}
//Añadimos los requerimientos de esta página: La clase Producto, la clase Votos y xajax.inc.php
require './include/Producto.php';
require './include/Votos.php';
require 'include/xajax_core/xajax.inc.php';
//Creamos un objeto Xajax
$xajax = new xajax();
//Creamos un objeto Votos
$voto = new Votos();
//Configuramos Xajax para que sepa dónde está xajax_core.js
$xajax->configure('javascript URI', './include/');
//Registramos la función de xajax vProbando
$xajax->register(XAJAX_FUNCTION, "vProbando");
//Le decimos a Xajax que procese todas las peticiones
$xajax->processRequest();
//Le decimos a Xajax que imprima el javascript en la página
$xajax->printJavascript();
//Creamos un objeto de la clase Producto
$productos=new Producto();
//Obtenemos todo el listado de productos
$todos=$productos->listadoProductos();

//Función para votar a los productos. Toma como argumento el formulario con la información necesaria del producto
function vProbando($info){
  //Empezamos creando una respuesta de Xajax
  $respuesta = new xajaxResponse();
  //Obtenemos la ID del producto que queremos puntuar del formulario
  $idproducto = $info["idproducto"];
  //Obtenemos la ID del usuario con la información de la sesión
  $idusuario = $_SESSION['usu'];
  //Obtenemos la puntuación que le queremos dar al producto del formulario
  $cantidad = $info['puntos'];
  //Creamos un nuevo objeto Votos
  $voto = new Votos();
  //Comprobamos que el voto vaya a ser único, para que un usuario no pueda votar dos veces al mismo producto
  if($voto->votoUnico($idproducto, $idusuario)===true){
    //Si el voto va a ser único, procedemos a introducirlo en la base de datos.
    $voto->votar($cantidad, $idproducto, $idusuario);
    //Añadimos a la variable $texto el mensaje con la puntuación, número de votos y estrellas llamando al método "puntuacion" de la clase Votos
    $texto = $voto->puntuacion($idproducto);
    //Creamos una variable que tendrá el nombre de la ID del apartado "puntuacion" de la lista correspondiente al producto que hemos votado
    $caja = "puntuacion".$info["idproducto"];
    //Asignamos al HTML interno de la "caja" donde está el texto de las votaciones el texto actualizado con la nueva votación
    $respuesta->assign($caja,"innerHTML",$texto);
  } else{
    //En caso de que NO vaya a ser un voto único, salta una alerta de JavaScript indicándonoslo
    $respuesta->alert("No puedes votar dos veces");
  }
  //Devolvemos la respuesta, es decir, o actualizar el texto, o la alerta
  return $respuesta;
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CDN -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <!--Fontawesome CDN-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
    <title>Productos</title>
</head>
<body style="background:gainsboro">
<div class="float float-right d-inline-flex mt-2">

    
    <i class="fas fa-user mr-3 fa-2x"></i>
    <input type="text" size='10px' value="<?php echo $_SESSION['usu']; ?>" class="form-control
    mr-2 bg-transparent text-info font-weight-bold" disabled>
    <a href="cerrar.php" class="btn btn-warning mr-2">Salir</a>
</div>
<br>
<h4 class="container text-center mt-4 font-weight-bold">Productos onLine</h4>
<div class="container mt-3">
<table class="table table-striped table-dark">
  <thead>
    <tr class='text-center'>
      <th scope="col">Código</th>
      <th scope="col">Nombre</th>
      <th scope="col">Nombre Corto</th>
      <th scope="col">Puntuacion</th>
      <th scope="col">Votar</th>
    </tr>
  </thead>
  <tbody>
      <?php
      //Bloque de código que muestra la lista de productos.
      //En la línea 113 hay un botón que llama a la función xajax_vProbando, función de JS creada por Xajax
        while($item=$todos->fetch(PDO::FETCH_OBJ)){
          echo <<< FIN
            <tr class='text-center'>
            <th scope='row'>{$item->id}</th>
            <td>{$item->nombre}</td>
            <td>{$item->nombre_corto}</td>
            <td id="puntuacion$item->id">{$voto->puntuacion($item->id)}</td>
            <td><form method="post" action="javascript:void(null)" id="formUsuario$item->id">
            <input type="hidden" name="idproducto" value="$item->id">
            <select name="puntos" id="puntos" form="formUsuario">
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
              <option value="5">5</option>
            </select>
            <input id="enviar" type="submit" value="Enviar" onclick = "xajax_vProbando(xajax.getFormValues('formUsuario$item->id'))" />
            </form></td>
            </tr>
FIN;
      }
      ?>
  </tbody>
</table>

</body>
</html>