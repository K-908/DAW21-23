<?php

namespace Clases;
require '../src/Clases1/Operaciones.php';

print "<h1>CLIENTE.PHP</h1>";
print "Precio: ".getPvp(1);
print "<br><hr>";
print "Cantidad: ".getStock(1, 1);
print "<br><hr>";
print "Lista de familias: <br>";
print_r(getFamilias());
print "<br><hr>";
print "Productos de la familia NETBOK: <br>";
print_r(getProductosFamilia("NETBOK"));