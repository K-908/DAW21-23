<?php

    namespace Clases;
    require_once 'Conexion.php';
    use PDO;
    use PDOException;

class Producto extends Conexion{
    public function __construct(){
        parent::__construct();
    }

    public function getProductos(){
        $consulta = "SELECT * FROM productos";
        $stmt = $this->conexion->prepare($consulta);
        try{
            $stmt->execute();
        } catch(PDOException $e){
            die("Error al obtener datos: ".$e->getMessage());
        }
        return $stmt->fetchAll(PDO::FETCH_OBJ);
    }
}