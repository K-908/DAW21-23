<?php
    namespace Clases;
    
    require_once 'Producto.php';
    require_once 'Stock.php';
    require_once 'Familia.php';

function getPvp($numID){
    $listaProductos = (new Producto)->getProductos();
    $precio = 0;
    foreach($listaProductos as $prod){
        if($prod->id == $numID){
            $precio = $prod->pvp;
        }
    }
    return $precio;
    $listaProductos = null;
};

function getStock($producto, $tienda){
    $listaStock = (new Stock)->getStocks();
    $cantidad = 0;
    foreach($listaStock as $lista){
        if($lista->producto == $producto && $lista->tienda == $tienda){
            $cantidad = $lista->unidades;
        }
    }
    return $cantidad;
    $listaStock = null;
}

function getFamilias(){
    $listaFamilias = (new Familia)->getFamilias();
    $familias = [];
    foreach($listaFamilias as $lista){
        array_push($familias, $lista->nombre);
    }
    return $familias;
}

function getProductosFamilia($codFamilia){
    $listaProductos = (new Producto)->getProductos();
    $lista = [];
    foreach($listaProductos as $prod){
        if($prod->familia == $codFamilia){
            array_push($lista, $prod->id);
        }
    }
    return $lista;
}

