<?php $__env->startSection('titulo'); ?>
    <?php echo e($titulo); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('cabecera'); ?>
    <?php echo e($cabecera); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

<?php
session_start();
$posiciones = ["Portero", "Defensa", "Lateral Izquierdo", "Lateral Derecho", "Central", "Delantero"];
if(isset($_POST['sendBar'])){
    $_SESSION['nombre'] = $_POST['nombre'];
    $_SESSION['apellidos'] = $_POST['apellidos'];
    $_SESSION['dorsal'] = $_POST['dorsal'];
    $_SESSION['posicion'] = $_POST['posicion'];
    header("Location:generarCode.php");
    die();
} else if(isset($_POST['submit'])){
    $_SESSION['nombre'] = $_POST['nombre'];
    $_SESSION['apellidos'] = $_POST['apellidos'];
    $_SESSION['dorsal'] = $_POST['dorsal'];
    $_SESSION['posicion'] = $_POST['posicion'];
    header("Location:crearJugador.php");
    die();
}



if(isset($_SESSION['mensaje'])){
    print "<div class=\"mensajeError\">".$_SESSION['mensaje']."</div>";
} else{
    $_SESSION['mensaje']="";
}

if(!isset($_SESSION['barcode'])){
    $_SESSION['barcode']= "";
}

if(!isset($_SESSION['nombre'])){
    $_SESSION['nombre']= "";
}

if(!isset($_SESSION['apellidos'])){
    $_SESSION['apellidos']= "";
}
if(!isset($_SESSION['dorsal'])){
    $_SESSION['dorsal']= 0;
}

if(!isset($_SESSION['posicion'])){
    $_SESSION['posicion']= "";
}
?>

<div class="container">
        <div class="row">
            <div class="col-md-6">
                <form method="post" action="<?php echo $_SERVER['PHP_SELF'] ?>">
                <label for="nombre">Nombre</label>
                <input type="text" name="nombre" value="<?php echo $_SESSION['nombre'] ?>" required>
            </div>
            <div class="col-md-6">
                <label for="apellidos">Apellidos</label>
                <input type="text" name="apellidos" value="<?php echo $_SESSION['apellidos'] ?>" required>
            </div>
            <div class="col-md-6">
                <label for="posicion">Posición</label>
                <select name="posicion" id="posicion">
                        <?php $__currentLoopData = $posiciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value=<?php echo e($pos); ?>><?php echo e($pos); ?></option> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>


            <div class="col-md-6">
                <label for="dorsal">Dorsal</label>
                <input type="number" name="dorsal" min="1" max="99" value="<?php echo $_SESSION['dorsal'] ?>"></br>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <label for="Código de barras">Código de barras</label>
                <input type="text" id="barcode" name="barcode" value="<?php echo $_SESSION['barcode'] ?>" readonly>
            </div>
            <div class="col-md-1"><input class="btn btn-primary float-left" type="submit" name="submit" value="Enviar"></div>
            <div class="col-md-1"><input class="btn btn-primary float-left" type="reset" name="borrar" value="borrar"></div>
            <div class="col-md-1"><input class="btn btn-primary float-left" type="submit"  name="sendBar" id="sendBar" value="Generar código"></div>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillas.plantilla1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dwes05_Tarea\views/vcrear.blade.php ENDPATH**/ ?>