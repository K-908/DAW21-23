<?php $__env->startSection('titulo'); ?>
    <?php echo e($titulo); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('cabecera'); ?>
    <?php echo e($cabecera); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
    <a href="crearDatos.php" type="button" class="btn btn-success" >Insertar datos de ejemplo</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillas.plantilla1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dwes05_Tarea\views/vinstalacion.blade.php ENDPATH**/ ?>