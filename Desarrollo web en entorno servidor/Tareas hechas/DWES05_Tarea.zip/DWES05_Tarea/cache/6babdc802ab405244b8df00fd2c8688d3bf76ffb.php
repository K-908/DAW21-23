<?php $__env->startSection('titulo'); ?>
    <?php echo e($titulo); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('cabecera'); ?>
    <?php echo e($cabecera); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

<?php
session_start();

if(isset($_SESSION['mensaje'])){
    print "<div class=\"mensajeCreado\">".$_SESSION['mensaje']."</div>";
    session_destroy();
}

?>

<div id="botonNuevoJugador">

<a href="fcrear.php" class="btn btn-primary btn-nuevoJugador float-left"><i class="fas fa-plus"></i> Nuevo Jugador</a>

</div>

<div class="contieneTabla">

    <table class="table table-striped table-dark">
        <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Nombre</th>
                <th scope="col">Apellidos</th>
                <th scope="col">Dorsal</th>
                <th scope="col">Posición</th>
                <th scope="col">Código de barras</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $listaJugadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr scope="row">
                <td><?php echo e($item->id); ?></td>
                <td><?php echo e($item->nombre); ?></td>
                <td><?php echo e($item->apellidos); ?></td>
                <td><?php echo e($item->dorsal); ?></td>
                <td><?php echo e($item->posicion); ?></td>
                <td><?php echo $d->getBarcodeHTML($item->barcode, 'EAN13', 2,45, 'white', true); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillas.plantilla1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dwes05_Tarea\views/vjugadores.blade.php ENDPATH**/ ?>