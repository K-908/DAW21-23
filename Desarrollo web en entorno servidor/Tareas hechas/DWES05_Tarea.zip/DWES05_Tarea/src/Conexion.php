<?php
//Página para crear la conexión
    namespace Clases;
    use PDO;
    use PDOException;

class Conexion{
    //Creamos las variables
    private $host;
    private $db;
    private $user;
    private $pass;
    private $dsn;
    protected $conexion;
    
    //constructur de la clase conexión
    public function __construct(){
        $this->host = "localhost";
        $this->db="practicaunidad5";
        $this->user="gestor";
        $this->pass="secreto";
        $this->dsn="mysql:host={$this->host};dbname={$this->db};charset=utf8mb4";
        $this->crearConexion();
    }
    //Función que hace uso del constructor y crea la conexión
    public function crearConexion(){
        try{
            $this->conexion = new PDO($this->dsn, $this->user, $this->pass);
            $this->conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch(PDOException $e){
            die("Error en la conexión: ".$e->getMessage());
        }
        return $this->conexion;
    }
}