@extends('plantillas.plantilla1')
<!-- Plantilla para la página que crea los datos de ejemplo. Le especificamos las secciones,
y las variables las sacará de la propia página que use esta vista-->
@section('titulo')
    {{$titulo}}
@endsection

@section('cabecera')
    {{$cabecera}}
@endsection

@section('contenido')
    <a href="crearDatos.php" type="button" class="btn btn-success" >Insertar datos de ejemplo</a>
@endsection