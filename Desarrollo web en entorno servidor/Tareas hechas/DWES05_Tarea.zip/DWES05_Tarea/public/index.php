<?php
//Página principa que no hace nada
require '../vendor/autoload.php';
use Clases\Conexion;
//Crea conexión
$insertar = (new Conexion())->crearConexion();
//Miramos a ver si hay algo en la base de datos
$comprobar = $insertar->query('SELECT * FROM jugadores');
//Si está vacía, nos lleva a la página "instalacion.php" que crea datos
if($comprobar->rowCount()==0){
    header("Location:instalacion.php");
    //Si no está vacía, nos lleva a la página jugadores.php, para ver la lista de jugadores
} else{
    header("Location:jugadores.php");
}