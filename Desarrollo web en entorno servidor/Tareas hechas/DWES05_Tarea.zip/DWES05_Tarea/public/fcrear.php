<?php
//Esta página carga la plantilla de blade con el formulario para crear jugador
require '../vendor/autoload.php';
use Philo\Blade\Blade;
use Clases\Jugador;
use \Milon\Barcode\DNS1D;
//Indicamos dónde están las carpetas "views" y "cache"
$views = '../views';
$cache = '../cache';
//Le asignamos los valores de las variables "Título" y "Cabecera" que están indicadas en la plantila
$titulo = "Página para crear jugador";
$cabecera = "Crear jugador";
//Creamos un objeto Blade
$blade = new Blade($views, $cache);
//Creamos la conexión
$jugadores = (new Jugador())->getJugadores();
//Hacemos que Blade "dibuje" la página
echo $blade->view()->make('vcrear', compact('titulo', 'cabecera', 'jugadores'))->render();