<?php
require '../vendor/autoload.php';
//Usamos el namespace Conexion
use Clases\Conexion;
//Creamos objeto Faker en español
$faker = Faker\Factory::create('es_ES');
//Creamos conexión
$insertar = (new Conexion())->crearConexion();
//Buscamos a los jugadores y metemos los dorsales y los barcodes en arrays para no repetirlos al crear datos
$resultado = $insertar->query('SELECT nombre, dorsal, barcode FROM jugadores');
$dorsales = [];
$barcodes = [];
while($row = $resultado->fetch()){
    array_push($dorsales, $row['dorsal']);
    array_push($barcodes, $row['barcode']);
}

//Para crear datos insertaremos 4 jugadores en la base de datos

for($i=0;$i<4;$i++) {
    //Permitirmos primeros nombres tanto masculinos como femeninos
    $nombre = $faker->firstName($gender=null);
    //Para la variable apellidos concatenamos dos apellidos en la misma variable
    $apellidos = $faker->lastName()." ".$faker->lastName();
    //Creamos la variable dorsal
    $dorsal;
    while(true){
        //Los dorsales pueden ir entre el 0 y el 99, seleccionamos un número aleatorio
        $dsa = $faker->numberBetween($min = 0, $max = 99);
        //Si el número que ha salido no está en el array anterior
        if(!in_array($dsa, $dorsales)){
            //Asignaremos ese número a la variable dorsal
            $dorsal = $dsa;
            break;
        }
    }
    //Número aleatorio entre 1 y 6 para la posición, ya que ese campo de la base de datos es un enum y con poner el número vale
    $posicion=$faker->numberBetween($min = 1, $max = 6);
    //Creams la variable barcode
    $barcode;
    while(true){
        //Creamos un barcode en formato ean13
        $dsa = $faker->ean13;
        //Si ese barcode no está en el array
        if(!in_array($dsa, $barcodes)){
            //Asignamos ese valor a la variable barcode
            $barcode = $dsa;
            break;
        }
    }
    //Con todos los datos creados correctamente, se añade el jugador a la base de datos
    try{
        $insertadatos = $insertar->query("INSERT INTO jugadores
        (nombre, apellidos, dorsal, posicion, barcode)
        VALUES ('$nombre', '$apellidos', '$dorsal', '$posicion', '$barcode')");
    }catch(PDOException $e){

    }
    }
    //Cerramos la conexión
    $insertar = null;
    //Volvemos a la página index.php
    header("Location:index.php");
