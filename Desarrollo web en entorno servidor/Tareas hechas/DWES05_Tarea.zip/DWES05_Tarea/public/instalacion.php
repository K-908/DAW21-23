<?php
//Página a la que accedemos si vamos a index.php y no hay nada en la base de datos
require '../vendor/autoload.php';
use Philo\Blade\Blade;
//indicamos dónde están las carpetas "views" y "cache"
$views = '../views';
$cache = '../cache';
//Indicamos el título y la cabecera de la página, para que la plantilla sepa qué poner
$titulo= "Inicio";
$cabecera ="Instalación";
//Creamos un objeto Blade con las carpetas views y cache como parámetros
$blade = new Blade($views, $cache);
//Blade "dibuja" la página
echo $blade->view()->make('vinstalacion', compact('titulo', 'cabecera'))->render();