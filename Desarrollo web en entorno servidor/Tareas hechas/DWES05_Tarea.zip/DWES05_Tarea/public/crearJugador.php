<?php
//Comenzamos la sesión
session_start();
require '../vendor/autoload.php';
use Clases\Conexion;
$insertar = (new Conexion())->crearConexion();
//Si ya hay una sesión activa con datos asignados, los asignamos a variables
if(isset($_SESSION['nombre'])){
    $nombre = $_SESSION['nombre'];
    $apellidos = $_SESSION['apellidos'];
    $dorsal = $_SESSION['dorsal'];
    $posicion = $_SESSION['posicion'];
    $barcode = $_SESSION['barcode'];
    $_SESSION ['mensaje'] = "";
} else{
    header("Location:fcrear.php");
}
//Creamos variables con todos los datos necesarios para crear un jugador y le damos el valor "true"
$nombreCorrecto = true;
$apellidoCorrecto = true;
$dorsalCorrecto = true;
$barcodeCorrecto = true;

//Si en el campo "nombre" solo hemos escrito espacios, nos aparece un mensaje de error
if(empty(trim($nombre))){
    //Cambiamos el valor de la variable a "false"
    $nombreCorrecto = false;
    $_SESSION['mensaje'].="Nombre incorrecto</br>";
}
//Si en el campo "apellidos" solo hemos escrito espacios, nos aparece un mensaje de error
if(empty(trim($apellidos))){
    //Cambiamos el valor de la variable a "false"
    $apellidoCorrecto = false;
    $_SESSION['mensaje'].="Debes introducir apellidos</br>";
}
//Si no hemos generado un código de barras, nos aparece un mensaje de error
if(empty($barcode)){
    //Cambiamos el valor de la variable a "false"
    $barcodeCorrecto = false;
    $_SESSION['mensaje'].="Debes generar un código de barras</br>";
}
//Si el dorsal que hemos selcecionado ya está en uso, nos aparece un mensaje de error
$mirarDorsal = $insertar->query('SELECT * FROM jugadores WHERE dorsal='.$dorsal.'');
if(!$mirarDorsal->rowCount()==0){
    //Cambiamos el valor de la variable a "false"
    $dorsalCorrecto = false;
    $_SESSION['mensaje'].="Dorsal ya en uso</br>";
}

//Si no ha habido ningún error y no hemos cambiado las variable a false
if($nombreCorrecto && $apellidoCorrecto && $dorsalCorrecto && $barcodeCorrecto){
    try{
        //Añadimos al jugador a la base de datos
        $addJugador = $insertar->query("INSERT INTO jugadores
        (nombre, apellidos, dorsal, posicion, barcode)
        VALUES ('$nombre', '$apellidos', '$dorsal', '$posicion', '$barcode')");
    }catch(PDOException $e){
        die("Error al insertar datos: ".$e->getMessage());
    }
    //Y volvemos a la página jugadores.php
    header("Location:jugadores.php");
    //Si ha habido algún error, nos devuelve a la página para crear jugador
} else{
    header("Location:fcrear.php");
}